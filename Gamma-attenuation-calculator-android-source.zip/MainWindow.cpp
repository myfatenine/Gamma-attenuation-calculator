#include "MainWindow.h"

#include "AttenuationPlot.h"

#include <QAction>
#include <QApplication>
#include <QDesktopServices>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QFrame>
#include <QGridLayout>
#include <QGroupBox>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QPushButton>
#include <QScrollArea>
#include <QSet>
#include <QStringList>
#include <QTableWidget>
#include <QUrl>
#include <QVBoxLayout>

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace {

QLineEdit *makeLineEdit(const QString &value, QWidget *parent)
{
    auto *edit = new QLineEdit(parent);
    edit->setText(value);
    return edit;
}

QString formatNumber(double value)
{
    return QString::number(value, 'g', 10);
}

const ElementInfo *parseElementText(const QString &text)
{
    bool ok = false;
    const int atomicNumber = text.trimmed().toInt(&ok);
    if (ok) {
        return AttenuationCalculator::elementByAtomicNumber(atomicNumber);
    }
    return AttenuationCalculator::elementBySymbol(text);
}

} // namespace

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
#ifdef Q_OS_ANDROID
    setMinimumSize(360, 600);
    setWindowFlag(Qt::FramelessWindowHint, true);
#else
    resize(900, 620);
#endif

    QString loadError;
    const QStringList dataPaths = {
#ifdef Q_OS_ANDROID
        QStringLiteral(":/data/data.csv"),
#endif
        QApplication::applicationDirPath() + QStringLiteral("/data.csv"),
        QStringLiteral("data.csv"),
        QStringLiteral(":/data/data.csv")
    };

    QString dataPath;
    for (const QString &candidate : dataPaths) {
        if (QFileInfo::exists(candidate)) {
            dataPath = candidate;
            break;
        }
    }

    if (!m_calculator.loadCsv(dataPath, &loadError)) {
        showError(loadError);
    }

    createLanguageMenu();
    rebuildUi();
}

void MainWindow::createLanguageMenu()
{
#ifdef Q_OS_ANDROID
    return;
#else
    menuBar()->clear();
    QMenu *languageMenu = menuBar()->addMenu(QStringLiteral("Language"));

    QAction *englishAction = languageMenu->addAction(QStringLiteral("English"));
    QAction *chineseAction = languageMenu->addAction(QStringLiteral("Chinese"));
    languageMenu->addSeparator();
    QAction *sourceAction = languageMenu->addAction(QStringLiteral("GitHub"));
    englishAction->setCheckable(true);
    chineseAction->setCheckable(true);
    englishAction->setChecked(m_language == UiLanguage::English);
    chineseAction->setChecked(m_language == UiLanguage::Chinese);

    connect(englishAction, &QAction::triggered, this, [this]() { setLanguage(UiLanguage::English); });
    connect(chineseAction, &QAction::triggered, this, [this]() { setLanguage(UiLanguage::Chinese); });
    connect(sourceAction, &QAction::triggered, this, &MainWindow::openSourceRepository);
#endif
}

void MainWindow::rebuildUi()
{
    setWindowTitle(text("windowTitle"));

    auto *central = new QWidget(this);
    auto *layout = new QVBoxLayout(central);
#ifdef Q_OS_ANDROID
    layout->setContentsMargins(10, 8, 10, 10);
    layout->setSpacing(8);
    layout->addWidget(createAndroidHeader());
#endif

    m_tabs = new QTabWidget(central);
    m_tabs->addTab(createScrollablePage(createSingleElementTab()), text("singleTab"));
    m_tabs->addTab(createScrollablePage(createFormulaMixtureTab()), text("formulaTab"));
    m_tabs->addTab(createScrollablePage(createManualMixtureTab()), text("manualTab"));

    layout->addWidget(m_tabs, 1);
    layout->addWidget(createResultsPanel());
    setCentralWidget(central);
}

QWidget *MainWindow::createAndroidHeader()
{
    auto *header = new QWidget(this);
    auto *layout = new QHBoxLayout(header);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(8);

    auto *title = new QLabel(text("windowTitle"), header);
    QFont titleFont = title->font();
    titleFont.setBold(true);
    titleFont.setPointSize(std::max(12, titleFont.pointSize() + 1));
    title->setFont(titleFont);
    title->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

    auto *languageButton = new QPushButton(header);
    languageButton->setText(m_language == UiLanguage::Chinese
                                ? QStringLiteral("English")
                                : QStringLiteral("中文"));
    languageButton->setMinimumWidth(92);
    connect(languageButton, &QPushButton::clicked, this, [this]() {
        const UiLanguage language = m_language == UiLanguage::Chinese
                                        ? UiLanguage::English
                                        : UiLanguage::Chinese;
        setLanguage(language);
    });

    auto *sourceButton = new QPushButton(QStringLiteral("GitHub"), header);
    sourceButton->setMinimumWidth(86);
    connect(sourceButton, &QPushButton::clicked, this, &MainWindow::openSourceRepository);

    layout->addWidget(title);
    layout->addWidget(languageButton);
    layout->addWidget(sourceButton);
    return header;
}

QWidget *MainWindow::createSingleElementTab()
{
    auto *tab = new QWidget(this);
    auto *layout = new QVBoxLayout(tab);
    auto *form = new QFormLayout();

    m_singleEnergy = makeLineEdit(QStringLiteral("662"), tab);
    m_singleAtomicNumber = makeLineEdit(QStringLiteral("82"), tab);
    m_singleDensity = makeLineEdit(QStringLiteral("11.34"), tab);

    form->addRow(text("energy"), m_singleEnergy);
    form->addRow(text("atomicNumber"), m_singleAtomicNumber);
    form->addRow(text("density"), m_singleDensity);

    auto *button = new QPushButton(text("calculateSingle"), tab);
    connect(button, &QPushButton::clicked, this, &MainWindow::calculateSingleElement);
    auto *exportButton = new QPushButton(text("exportCurve"), tab);
    connect(exportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);

    m_singlePlot = new AttenuationPlot(tab);
    setupPlot(m_singlePlot);

    auto *buttonRow = new QGridLayout();
    buttonRow->addWidget(button, 0, 0);
    buttonRow->addWidget(exportButton, 0, 1);

    layout->addLayout(form);
    layout->addLayout(buttonRow);
    layout->addWidget(m_singlePlot);
    layout->addStretch(1);
    return tab;
}

QWidget *MainWindow::createFormulaMixtureTab()
{
    auto *tab = new QWidget(this);
    auto *layout = new QVBoxLayout(tab);
    auto *form = new QFormLayout();

    m_formulaEnergy = makeLineEdit(QStringLiteral("662"), tab);
    m_formulaInput = makeLineEdit(QStringLiteral("H2O"), tab);
    m_formulaInput->setPlaceholderText(text("formulaPlaceholder"));
    m_formulaDensity = makeLineEdit(QStringLiteral("1"), tab);

    form->addRow(text("energy"), m_formulaEnergy);
    form->addRow(text("formula"), m_formulaInput);
    form->addRow(text("mixtureDensity"), m_formulaDensity);

    auto *button = new QPushButton(text("calculateFormula"), tab);
    connect(button, &QPushButton::clicked, this, &MainWindow::calculateFormulaMixture);
    auto *exportButton = new QPushButton(text("exportCurve"), tab);
    connect(exportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);

    m_formulaPlot = new AttenuationPlot(tab);
    setupPlot(m_formulaPlot);

    m_fractionTable = new QTableWidget(0, 3, tab);
    m_fractionTable->setHorizontalHeaderLabels({text("element"),
                                                text("atomicNumber"),
                                                text("massPercent")});
    m_fractionTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    m_fractionTable->setEditTriggers(QAbstractItemView::NoEditTriggers);

    auto *buttonRow = new QGridLayout();
    buttonRow->addWidget(button, 0, 0);
    buttonRow->addWidget(exportButton, 0, 1);

    layout->addLayout(form);
    layout->addLayout(buttonRow);
    layout->addWidget(m_formulaPlot);
    layout->addWidget(m_fractionTable, 1);
    return tab;
}

QWidget *MainWindow::createManualMixtureTab()
{
    auto *tab = new QWidget(this);
    auto *layout = new QVBoxLayout(tab);
    auto *form = new QFormLayout();

    m_manualEnergy = makeLineEdit(QStringLiteral("662"), tab);
    m_manualDensity = makeLineEdit(QStringLiteral("1"), tab);
    form->addRow(text("energy"), m_manualEnergy);
    form->addRow(text("mixtureDensity"), m_manualDensity);

    m_manualTable = new QTableWidget(0, 2, tab);
    m_manualTable->setHorizontalHeaderLabels({text("elementInput"),
                                              text("massPercent")});
    m_manualTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    auto *buttonsLayout = new QGridLayout();
    auto *addButton = new QPushButton(text("addElement"), tab);
    auto *removeButton = new QPushButton(text("removeSelected"), tab);
    auto *calculateButton = new QPushButton(text("calculateManual"), tab);
    auto *exportButton = new QPushButton(text("exportCurve"), tab);
    connect(addButton, &QPushButton::clicked, this, [this]() { addManualRow(); });
    connect(removeButton, &QPushButton::clicked, this, &MainWindow::removeSelectedManualRows);
    connect(calculateButton, &QPushButton::clicked, this, &MainWindow::calculateManualMixture);
    connect(exportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);
    buttonsLayout->addWidget(addButton, 0, 0);
    buttonsLayout->addWidget(removeButton, 0, 1);
    buttonsLayout->addWidget(calculateButton, 0, 2);
    buttonsLayout->addWidget(exportButton, 0, 3);

    addManualRow(QStringLiteral("Pb"), 50.0);
    addManualRow(QStringLiteral("Sn"), 50.0);

    m_manualPlot = new AttenuationPlot(tab);
    setupPlot(m_manualPlot);

    layout->addLayout(form);
    layout->addWidget(m_manualTable, 1);
    layout->addLayout(buttonsLayout);
    layout->addWidget(m_manualPlot);
    return tab;
}

QWidget *MainWindow::createResultsPanel()
{
    auto *group = new QGroupBox(text("results"), this);
    auto *layout = new QGridLayout(group);

    m_massCoefficientValue = new QLabel(QStringLiteral("-"), group);
    m_linearCoefficientValue = new QLabel(QStringLiteral("-"), group);
    m_halfValueLayerValue = new QLabel(QStringLiteral("-"), group);
    m_attenuation95Value = new QLabel(QStringLiteral("-"), group);

    layout->addWidget(new QLabel(text("massCoefficient"), group), 0, 0);
    layout->addWidget(m_massCoefficientValue, 0, 1);
    layout->addWidget(new QLabel(text("linearCoefficient"), group), 1, 0);
    layout->addWidget(m_linearCoefficientValue, 1, 1);
    layout->addWidget(new QLabel(text("halfValueLayer"), group), 2, 0);
    layout->addWidget(m_halfValueLayerValue, 2, 1);
    layout->addWidget(new QLabel(text("attenuation95"), group), 3, 0);
    layout->addWidget(m_attenuation95Value, 3, 1);

    return group;
}

QWidget *MainWindow::createScrollablePage(QWidget *content)
{
#ifdef Q_OS_ANDROID
    auto *scrollArea = new QScrollArea(this);
    scrollArea->setWidgetResizable(true);
    scrollArea->setFrameShape(QFrame::NoFrame);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollArea->setWidget(content);
    return scrollArea;
#else
    return content;
#endif
}

void MainWindow::calculateSingleElement()
{
    double energy = 0.0;
    double density = 0.0;
    int atomicNumber = 0;
    if (!readRequiredDouble(m_singleEnergy, &energy)
        || !readRequiredInt(m_singleAtomicNumber, &atomicNumber)
        || !readRequiredDouble(m_singleDensity, &density)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateAtomicNumber(atomicNumber) || !validateEnergy(energy)) {
        return;
    }

    try {
        showResult(m_calculator.calculateSingle(atomicNumber, energy, density));
        m_fractionTable->clearContents();
        m_fractionTable->setRowCount(0);
    } catch (const std::exception &ex) {
        showError(QString::fromLocal8Bit(ex.what()));
    }
}

void MainWindow::calculateFormulaMixture()
{
    double energy = 0.0;
    double density = 0.0;
    if (!readRequiredDouble(m_formulaEnergy, &energy)
        || m_formulaInput->text().trimmed().isEmpty()
        || !readRequiredDouble(m_formulaDensity, &density)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateEnergy(energy)) {
        return;
    }

    QString errorMessage;
    const QVector<MixtureComponent> components =
        FormulaParser::parseMassFractions(m_formulaInput->text(), &errorMessage);
    if (components.isEmpty()) {
        showError(m_language == UiLanguage::English ? text("invalidFormula") : errorMessage);
        return;
    }

    try {
        showMassFractions(components);
        showResult(m_calculator.calculateMixture(components, energy, density));
    } catch (const std::exception &ex) {
        showError(QString::fromLocal8Bit(ex.what()));
    }
}

void MainWindow::calculateManualMixture()
{
    double energy = 0.0;
    double density = 0.0;
    if (!readRequiredDouble(m_manualEnergy, &energy)
        || !readRequiredDouble(m_manualDensity, &density)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateEnergy(energy)) {
        return;
    }

    bool ok = false;
    const QVector<MixtureComponent> components = manualComponents(&ok);
    if (!ok) {
        return;
    }

    try {
        showMassFractions(components);
        showResult(m_calculator.calculateMixture(components, energy, density));
    } catch (const std::exception &ex) {
        showError(QString::fromLocal8Bit(ex.what()));
    }
}

void MainWindow::addManualRow(const QString &element, double percent)
{
    const int row = m_manualTable->rowCount();
    m_manualTable->insertRow(row);
    m_manualTable->setItem(row, 0, new QTableWidgetItem(element));
    m_manualTable->setItem(row, 1, new QTableWidgetItem(percent > 0.0 ? formatNumber(percent) : QString()));
}

void MainWindow::removeSelectedManualRows()
{
    QSet<int> rowsToRemove;
    QSet<int> percentRowsToClear;

    for (const QModelIndex &index : m_manualTable->selectionModel()->selectedIndexes()) {
        if (index.column() == 0) {
            rowsToRemove.insert(index.row());
        } else if (index.column() == 1) {
            percentRowsToClear.insert(index.row());
        }
    }

    for (const QModelIndex &index : m_manualTable->selectionModel()->selectedRows()) {
        rowsToRemove.insert(index.row());
    }

    for (int row : rowsToRemove) {
        percentRowsToClear.remove(row);
    }

    for (int row : percentRowsToClear) {
        QTableWidgetItem *item = m_manualTable->item(row, 1);
        if (item) {
            item->setText(QString());
        }
    }

    QList<int> rows = rowsToRemove.values();
    std::sort(rows.begin(), rows.end(), std::greater<int>());
    for (int row : rows) {
        m_manualTable->removeRow(row);
    }
}

void MainWindow::setLanguage(UiLanguage language)
{
    if (m_language == language) {
        return;
    }
    m_language = language;
    createLanguageMenu();
    rebuildUi();
}

void MainWindow::openSourceRepository()
{
    QDesktopServices::openUrl(QUrl(QStringLiteral("https://github.com/myfatenine/Gamma-attenuation-calculator")));
}

bool MainWindow::readRequiredDouble(QLineEdit *edit, double *value)
{
    const QString input = edit->text().trimmed();
    if (input.isEmpty()) {
        return false;
    }

    bool ok = false;
    const double parsed = input.toDouble(&ok);
    if (!ok) {
        return false;
    }
    *value = parsed;
    return true;
}

bool MainWindow::readRequiredInt(QLineEdit *edit, int *value)
{
    const QString input = edit->text().trimmed();
    if (input.isEmpty()) {
        return false;
    }

    bool ok = false;
    const int parsed = input.toInt(&ok);
    if (!ok) {
        return false;
    }
    *value = parsed;
    return true;
}

bool MainWindow::validateEnergy(double energyKeV)
{
    if (energyKeV < 100.0 || energyKeV > 20000.0) {
        showError(text("energyRange"));
        return false;
    }
    return true;
}

bool MainWindow::validateAtomicNumber(int atomicNumber)
{
    if (atomicNumber < 1 || atomicNumber > 92) {
        showError(text("atomicRange"));
        return false;
    }
    return true;
}

void MainWindow::setupPlot(AttenuationPlot *plot)
{
    plot->setLanguageText(text("plotTitle"),
                          text("plotXAxis"),
                          text("plotYAxis"),
                          text("plotEmpty"),
                          text("plotEnd"),
                          text("plotHalf"),
                          text("plot95"));
}

AttenuationPlot *MainWindow::currentPlot() const
{
    if (m_tabs->currentIndex() == 0) {
        return m_singlePlot;
    }
    if (m_tabs->currentIndex() == 1) {
        return m_formulaPlot;
    }
    if (m_tabs->currentIndex() == 2) {
        return m_manualPlot;
    }
    return nullptr;
}

void MainWindow::updateCurrentPlot(const AttenuationResult &result)
{
    AttenuationPlot *plot = currentPlot();
    if (plot) {
        plot->setLinearCoefficient(result.linearCoefficient);
    }
}

void MainWindow::exportCurrentCurve()
{
    AttenuationPlot *plot = currentPlot();
    if (!plot || !plot->hasCurve()) {
        showError(text("plotNoData"));
        return;
    }

    QString filePath = QFileDialog::getSaveFileName(this,
                                                    text("exportCaption"),
                                                    QStringLiteral("attenuation_curve.csv"),
                                                    QStringLiteral("CSV files (*.csv)"));
    if (filePath.isEmpty()) {
        return;
    }
    if (!filePath.endsWith(QStringLiteral(".csv"), Qt::CaseInsensitive)) {
        filePath += QStringLiteral(".csv");
    }

    QString errorMessage;
    if (!plot->exportCsv(filePath, &errorMessage)) {
        showError(text("exportFailed").arg(errorMessage));
        return;
    }
    QMessageBox::information(this, text("exportDoneTitle"), text("exportDone").arg(filePath));
}

void MainWindow::showResult(const AttenuationResult &result)
{
    if (result.linearCoefficient <= 0.0 || !std::isfinite(result.linearCoefficient)) {
        showError(text("invalidLinearCoefficient"));
        return;
    }

    m_massCoefficientValue->setText(formatNumber(result.massCoefficient));
    m_linearCoefficientValue->setText(formatNumber(result.linearCoefficient));
    m_halfValueLayerValue->setText(formatNumber(result.halfValueLayer));
    m_attenuation95Value->setText(formatNumber(result.attenuation95Thickness));
    updateCurrentPlot(result);
}

void MainWindow::showMassFractions(const QVector<MixtureComponent> &components)
{
    m_fractionTable->clearContents();
    m_fractionTable->setRowCount(components.size());
    for (int row = 0; row < components.size(); ++row) {
        const MixtureComponent &component = components[row];
        const ElementInfo *element = AttenuationCalculator::elementByAtomicNumber(component.atomicNumber);
        m_fractionTable->setItem(row, 0, new QTableWidgetItem(QString::fromLatin1(element->symbol)));
        m_fractionTable->setItem(row, 1, new QTableWidgetItem(QString::number(component.atomicNumber)));
        m_fractionTable->setItem(row, 2, new QTableWidgetItem(formatNumber(component.massFraction * 100.0)));
    }
}

void MainWindow::showError(const QString &message)
{
    QMessageBox::warning(this, QStringLiteral("ERROR"), message);
}

QVector<MixtureComponent> MainWindow::manualComponents(bool *ok)
{
    *ok = false;
    QMap<int, double> percentByElement;
    double percentSum = 0.0;

    for (int row = 0; row < m_manualTable->rowCount(); ++row) {
        const QTableWidgetItem *elementItem = m_manualTable->item(row, 0);
        const QTableWidgetItem *percentItem = m_manualTable->item(row, 1);
        const QString elementText = elementItem ? elementItem->text().trimmed() : QString();
        const QString percentText = percentItem ? percentItem->text().trimmed() : QString();
        if (elementText.isEmpty() && percentText.isEmpty()) {
            continue;
        }

        const ElementInfo *element = parseElementText(elementText);
        if (!element) {
            showError(text("manualElementInvalid").arg(row + 1));
            return {};
        }

        bool numberOk = false;
        const double percent = percentText.toDouble(&numberOk);
        if (!numberOk || percent < 0.0 || percent > 100.0) {
            showError(text("manualPercentInvalid").arg(row + 1));
            return {};
        }

        percentByElement[element->atomicNumber] += percent;
        percentSum += percent;
    }

    if (percentByElement.isEmpty()) {
        showError(text("manualEmpty"));
        return {};
    }
    if (std::fabs(percentSum - 100.0) > 0.01) {
        showError(text("manualSum").arg(formatNumber(percentSum)));
        return {};
    }

    QVector<MixtureComponent> components;
    for (auto it = percentByElement.cbegin(); it != percentByElement.cend(); ++it) {
        components.push_back({it.key(), it.value() / 100.0});
    }
    *ok = true;
    return components;
}

QString MainWindow::text(const char *key) const
{
    const QString id = QString::fromLatin1(key);
    const bool english = m_language == UiLanguage::English;

    if (id == QStringLiteral("windowTitle")) {
        return QStringLiteral("Gamma attenuation calculator");
    }
    if (id == QStringLiteral("singleTab")) {
        return english ? QStringLiteral("Single element") : QStringLiteral("单元素");
    }
    if (id == QStringLiteral("formulaTab")) {
        return english ? QStringLiteral("Formula mixture") : QStringLiteral("分子式混合物");
    }
    if (id == QStringLiteral("manualTab")) {
        return english ? QStringLiteral("Manual mixture") : QStringLiteral("手动百分比混合物");
    }
    if (id == QStringLiteral("energy")) {
        return english ? QStringLiteral("Energy (keV)") : QStringLiteral("能量 (keV)");
    }
    if (id == QStringLiteral("atomicNumber")) {
        return english ? QStringLiteral("Atomic number") : QStringLiteral("原子序数");
    }
    if (id == QStringLiteral("density")) {
        return english ? QStringLiteral("Material density (g/cm^3)") : QStringLiteral("材料密度 (g/cm^3)");
    }
    if (id == QStringLiteral("mixtureDensity")) {
        return english ? QStringLiteral("Mixture density (g/cm^3)") : QStringLiteral("混合物密度 (g/cm^3)");
    }
    if (id == QStringLiteral("formula")) {
        return english ? QStringLiteral("Molecular formula") : QStringLiteral("分子式");
    }
    if (id == QStringLiteral("formulaPlaceholder")) {
        return english ? QStringLiteral("Examples: H2O, CaCO3, Fe2(SO4)3, CuSO4·5H2O")
                       : QStringLiteral("例如：H2O、CaCO3、Fe2(SO4)3、CuSO4·5H2O");
    }
    if (id == QStringLiteral("calculateSingle")) {
        return english ? QStringLiteral("begin to calculate") : QStringLiteral("开始计算");
    }
    if (id == QStringLiteral("calculateFormula")) {
        return english ? QStringLiteral("begin to calculate") : QStringLiteral("开始计算");
    }
    if (id == QStringLiteral("calculateManual")) {
        return english ? QStringLiteral("begin to calculate") : QStringLiteral("开始计算");
    }
    if (id == QStringLiteral("element")) {
        return english ? QStringLiteral("Element") : QStringLiteral("元素");
    }
    if (id == QStringLiteral("elementInput")) {
        return english ? QStringLiteral("Element symbol or atomic number") : QStringLiteral("元素符号或原子序数");
    }
    if (id == QStringLiteral("massPercent")) {
        return english ? QStringLiteral("Mass percentage (%)") : QStringLiteral("质量百分比 (%)");
    }
    if (id == QStringLiteral("addElement")) {
        return english ? QStringLiteral("Add element") : QStringLiteral("添加元素");
    }
    if (id == QStringLiteral("removeSelected")) {
        return english ? QStringLiteral("Remove selected") : QStringLiteral("删除选中");
    }
    if (id == QStringLiteral("results")) {
        return english ? QStringLiteral("Calculation results") : QStringLiteral("计算结果");
    }
    if (id == QStringLiteral("massCoefficient")) {
        return english ? QStringLiteral("Gamma ray mass attenuation coefficient (cm^2/g)")
                       : QStringLiteral("γ质量衰减系数 (cm^2/g)");
    }
    if (id == QStringLiteral("linearCoefficient")) {
        return english ? QStringLiteral("Gamma ray line attenuation coefficient (1/cm)")
                       : QStringLiteral("γ线衰减系数 (1/cm)");
    }
    if (id == QStringLiteral("halfValueLayer")) {
        return english ? QStringLiteral("Gamma ray half-attenuation thickness (cm)")
                       : QStringLiteral("半衰减厚度 (cm)");
    }
    if (id == QStringLiteral("attenuation95")) {
        return english ? QStringLiteral("Gamma ray 95% attenuation thickness (cm)")
                       : QStringLiteral("95% 衰减厚度 (cm)");
    }
    if (id == QStringLiteral("incomplete")) {
        return english ? QStringLiteral("Please enter all required data!")
                       : QStringLiteral("请将数据输入完整！");
    }
    if (id == QStringLiteral("atomicRange")) {
        return english ? QStringLiteral("The supported atomic number range is 1 to 92")
                       : QStringLiteral("支持原子序数范围为1到92");
    }
    if (id == QStringLiteral("energyRange")) {
        return english ? QStringLiteral("The supported energy range is 100~20000keV")
                       : QStringLiteral("支持能量范围为100~20000keV");
    }
    if (id == QStringLiteral("invalidFormula")) {
        return QStringLiteral("Please enter a valid molecular formula.");
    }
    if (id == QStringLiteral("invalidLinearCoefficient")) {
        return english ? QStringLiteral("The calculated line attenuation coefficient is invalid. Please check the input data.")
                       : QStringLiteral("计算得到的线衰减系数无效，请检查输入数据。");
    }
    if (id == QStringLiteral("manualElementInvalid")) {
        return english ? QStringLiteral("Row %1 has an invalid element. Enter an element symbol or atomic number from 1 to 92.")
                       : QStringLiteral("第 %1 行元素无效，请输入元素符号或 1-92 的原子序数。");
    }
    if (id == QStringLiteral("manualPercentInvalid")) {
        return english ? QStringLiteral("Row %1 has an invalid mass percentage.")
                       : QStringLiteral("第 %1 行质量百分比无效。");
    }
    if (id == QStringLiteral("manualEmpty")) {
        return english ? QStringLiteral("Enter at least one element percentage.")
                       : QStringLiteral("请至少输入一个元素百分比。");
    }
    if (id == QStringLiteral("manualSum")) {
        return english ? QStringLiteral("The manual mass percentages should sum to 100%. Current total: %1%.")
                       : QStringLiteral("手动输入的质量百分比总和应为 100%，当前为 %1%。");
    }
    if (id == QStringLiteral("plotTitle")) {
        return english ? QStringLiteral("Attenuation versus thickness")
                       : QStringLiteral("衰减率随厚度变化曲线");
    }
    if (id == QStringLiteral("plotXAxis")) {
        return english ? QStringLiteral("Thickness (cm)")
                       : QStringLiteral("厚度 (cm)");
    }
    if (id == QStringLiteral("plotYAxis")) {
        return english ? QStringLiteral("Attenuation (%)")
                       : QStringLiteral("衰减率 (%)");
    }
    if (id == QStringLiteral("plotEmpty")) {
        return english ? QStringLiteral("Click calculate to draw the curve")
                       : QStringLiteral("点击开始计算后绘制曲线");
    }
    if (id == QStringLiteral("plotEnd")) {
        return english ? QStringLiteral("99% attenuation")
                       : QStringLiteral("99% 衰减");
    }
    if (id == QStringLiteral("plotHalf")) {
        return english ? QStringLiteral("HVL")
                       : QStringLiteral("半衰减");
    }
    if (id == QStringLiteral("plot95")) {
        return english ? QStringLiteral("95%")
                       : QStringLiteral("95%");
    }
    if (id == QStringLiteral("exportCurve")) {
        return english ? QStringLiteral("Export CSV")
                       : QStringLiteral("导出 CSV");
    }
    if (id == QStringLiteral("plotNoData")) {
        return english ? QStringLiteral("Please calculate a curve before exporting.")
                       : QStringLiteral("请先计算生成曲线后再导出。");
    }
    if (id == QStringLiteral("exportCaption")) {
        return english ? QStringLiteral("Export attenuation curve")
                       : QStringLiteral("导出衰减曲线");
    }
    if (id == QStringLiteral("exportFailed")) {
        return english ? QStringLiteral("Failed to export CSV: %1")
                       : QStringLiteral("导出 CSV 失败：%1");
    }
    if (id == QStringLiteral("exportDoneTitle")) {
        return english ? QStringLiteral("Export complete")
                       : QStringLiteral("导出完成");
    }
    if (id == QStringLiteral("exportDone")) {
        return english ? QStringLiteral("Curve data was exported to:\n%1")
                       : QStringLiteral("曲线数据已导出到：\n%1");
    }

    return id;
}

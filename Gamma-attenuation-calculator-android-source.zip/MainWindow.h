#pragma once

#include "AttenuationCalculator.h"

#include <QMainWindow>

class AttenuationPlot;
class QLabel;
class QLineEdit;
class QTableWidget;
class QTabWidget;
class QWidget;

enum class UiLanguage {
    Chinese,
    English
};

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private:
    void createLanguageMenu();
    void rebuildUi();
    QWidget *createAndroidHeader();
    QWidget *createSingleElementTab();
    QWidget *createFormulaMixtureTab();
    QWidget *createManualMixtureTab();
    QWidget *createResultsPanel();
    QWidget *createScrollablePage(QWidget *content);

    void calculateSingleElement();
    void calculateFormulaMixture();
    void calculateManualMixture();
    void addManualRow(const QString &element = QString(), double percent = 0.0);
    void removeSelectedManualRows();
    void setLanguage(UiLanguage language);
    void openSourceRepository();

    bool readRequiredDouble(QLineEdit *edit, double *value);
    bool readRequiredInt(QLineEdit *edit, int *value);
    bool validateEnergy(double energyKeV);
    bool validateAtomicNumber(int atomicNumber);

    void setupPlot(AttenuationPlot *plot);
    AttenuationPlot *currentPlot() const;
    void updateCurrentPlot(const AttenuationResult &result);
    void exportCurrentCurve();
    void showResult(const AttenuationResult &result);
    void showMassFractions(const QVector<MixtureComponent> &components);
    void showError(const QString &message);
    QVector<MixtureComponent> manualComponents(bool *ok);
    QString text(const char *key) const;

    AttenuationCalculator m_calculator;
    UiLanguage m_language = UiLanguage::Chinese;

    QTabWidget *m_tabs = nullptr;
    QLineEdit *m_singleEnergy = nullptr;
    QLineEdit *m_singleAtomicNumber = nullptr;
    QLineEdit *m_singleDensity = nullptr;
    AttenuationPlot *m_singlePlot = nullptr;

    QLineEdit *m_formulaEnergy = nullptr;
    QLineEdit *m_formulaInput = nullptr;
    QLineEdit *m_formulaDensity = nullptr;
    QTableWidget *m_fractionTable = nullptr;
    AttenuationPlot *m_formulaPlot = nullptr;

    QLineEdit *m_manualEnergy = nullptr;
    QLineEdit *m_manualDensity = nullptr;
    QTableWidget *m_manualTable = nullptr;
    AttenuationPlot *m_manualPlot = nullptr;

    QLabel *m_massCoefficientValue = nullptr;
    QLabel *m_linearCoefficientValue = nullptr;
    QLabel *m_halfValueLayerValue = nullptr;
    QLabel *m_attenuation95Value = nullptr;
};

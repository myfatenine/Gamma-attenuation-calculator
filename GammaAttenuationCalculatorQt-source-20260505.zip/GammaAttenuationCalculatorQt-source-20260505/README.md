# Gamma Attenuation Calculator Qt

Qt/CMake source release for the Gamma Attenuation Calculator.

## Requirements

- Windows x64
- Qt 5.15.x with MSVC 2019 64-bit kit
- CMake 3.16 or newer
- Visual Studio 2019 C++ build tools

## Build

From this directory:

```powershell
cmake -S . -B build -DCMAKE_PREFIX_PATH=D:/G4/QT5/5.15.2/msvc2019_64
cmake --build build --config Release
```

Adjust `CMAKE_PREFIX_PATH` to your local Qt installation path.

The executable will be generated at:

```text
build/Release/GammaAttenuationCalculatorQt.exe
```

## Runtime Data

Keep `data.csv` next to the executable. The CMake project copies it automatically after build.

## Features

- Single-element gamma-ray attenuation calculation.
- Mixture attenuation from molecular formula.
- Mixture attenuation from manually entered element mass percentages.
- Chinese and English UI.
- Attenuation curve to 99% attenuation.
- Half-value layer and 95% attenuation thickness markers.
- Curve CSV export.

## Source Files

- `main.cpp`
- `MainWindow.h/.cpp`
- `AttenuationCalculator.h/.cpp`
- `AttenuationPlot.h/.cpp`
- `CMakeLists.txt`
- `data.csv`

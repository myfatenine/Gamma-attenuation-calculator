#pragma once

#include "AttenuationCalculator.h"

#include <QString>
#include <QVector>

struct NistMaterial {
    QString name;
    double density = 0.0;
};

class NistDatabase {
public:
    bool open(QString *errorMessage = nullptr);
    bool isOpen() const;

    QVector<NistMaterial> searchMaterials(const QString &query, QString *errorMessage = nullptr) const;
    bool materialByName(const QString &name, NistMaterial *material, QString *errorMessage = nullptr) const;
    bool massAttenuationCoefficient(int atomicNumber,
                                    double energyKeV,
                                    double *coefficient,
                                    QString *errorMessage = nullptr) const;
    bool calculateSingle(int atomicNumber,
                         double energyKeV,
                         double density,
                         AttenuationResult *result,
                         QString *errorMessage = nullptr) const;
    bool calculateMixture(const QVector<MixtureComponent> &components,
                          double energyKeV,
                          double density,
                          AttenuationResult *result,
                          QString *errorMessage = nullptr) const;
    bool calculateMaterial(const QString &name,
                           double energyKeV,
                           double density,
                           AttenuationResult *result,
                           QString *errorMessage = nullptr) const;

private:
    QString databasePath(QString *errorMessage) const;
    bool elementTableName(int atomicNumber, QString *tableName, QString *errorMessage) const;
    bool tableMassAttenuationCoefficient(const QString &tableName,
                                         double energyKeV,
                                         double *coefficient,
                                         QString *errorMessage) const;
    static void fillResult(double massCoefficient, double density, AttenuationResult *result);
    static QString quoteIdentifier(const QString &identifier);
    static bool interpolateMassCoefficient(const QVector<double> &energiesMeV,
                                           const QVector<double> &coefficients,
                                           double energyMeV,
                                           double *coefficient);

    QString m_connectionName;
};

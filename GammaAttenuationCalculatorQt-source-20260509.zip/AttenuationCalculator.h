#pragma once

#include <QMap>
#include <QString>
#include <QVector>

struct ElementInfo {
    int atomicNumber;
    const char *symbol;
    const char *englishName;
    double atomicWeight;
};

struct AttenuationResult {
    double massCoefficient = 0.0;
    double linearCoefficient = 0.0;
    double halfValueLayer = 0.0;
    double attenuation95Thickness = 0.0;
};

struct MixtureComponent {
    int atomicNumber = 0;
    double massFraction = 0.0;
};

class AttenuationCalculator {
public:
    bool loadCsv(const QString &path, QString *errorMessage = nullptr);
    bool isLoaded() const;

    double massAttenuationCoefficient(int atomicNumber, double energyKeV) const;
    AttenuationResult calculateSingle(int atomicNumber, double energyKeV, double density) const;
    AttenuationResult calculateMixture(const QVector<MixtureComponent> &components,
                                       double energyKeV,
                                       double density) const;

    static const QVector<ElementInfo> &elements();
    static const ElementInfo *elementByAtomicNumber(int atomicNumber);
    static const ElementInfo *elementBySymbol(const QString &symbol);
    static QString elementLabel(int atomicNumber);

private:
    struct Coefficients {
        double a1 = 0.0;
        double a2 = 0.0;
        double a3 = 0.0;
        double highA1 = 0.0;
        double highA2 = 0.0;
        double highA3 = 0.0;
    };

    QVector<Coefficients> m_coefficients;
};

class FormulaParser {
public:
    static QVector<MixtureComponent> parseMassFractions(const QString &formula, QString *errorMessage);

private:
    explicit FormulaParser(QString formula);

    QMap<int, double> parseFormula(QChar terminator = QChar());
    QMap<int, double> parseGroup(QChar openChar);
    double parseNumber(double defaultValue);
    QString parseElementSymbol();
    void mergeCounts(QMap<int, double> *target, const QMap<int, double> &source, double multiplier);
    QChar matchingTerminator(QChar openChar) const;

    QString m_formula;
    int m_pos = 0;
    QString m_error;
};

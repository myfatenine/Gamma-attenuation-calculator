#include "MainWindow.h"

#include "AttenuationPlot.h"

#include <QAction>
#include <QApplication>
#include <QDesktopServices>
#include <QFileDialog>
#include <QFileInfo>
#include <QFormLayout>
#include <QFrame>
#include <QGridLayout>
#include <QGroupBox>
#include <QHeaderView>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QPushButton>
#include <QScrollArea>
#include <QSet>
#include <QStringList>
#include <QTableWidget>
#include <QTabWidget>
#include <QUrl>
#include <QVBoxLayout>

#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace {

QLineEdit *makeLineEdit(const QString &value, QWidget *parent)
{
    auto *edit = new QLineEdit(parent);
    edit->setText(value);
    return edit;
}

QString formatNumber(double value)
{
    return QString::number(value, 'g', 10);
}

const ElementInfo *parseElementText(const QString &text)
{
    bool ok = false;
    const int atomicNumber = text.trimmed().toInt(&ok);
    if (ok) {
        return AttenuationCalculator::elementByAtomicNumber(atomicNumber);
    }
    return AttenuationCalculator::elementBySymbol(text);
}

} // namespace

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
#ifdef Q_OS_ANDROID
    setMinimumSize(360, 600);
    setWindowFlag(Qt::FramelessWindowHint, true);
#else
    resize(900, 620);
#endif

    QString loadError;
    const QStringList dataPaths = {
#ifdef Q_OS_ANDROID
        QStringLiteral(":/data/data.csv"),
#endif
        QApplication::applicationDirPath() + QStringLiteral("/data.csv"),
        QStringLiteral("data.csv"),
        QStringLiteral(":/data/data.csv")
    };

    QString dataPath;
    for (const QString &candidate : dataPaths) {
        if (QFileInfo::exists(candidate)) {
            dataPath = candidate;
            break;
        }
    }

    if (!m_calculator.loadCsv(dataPath, &loadError)) {
        showError(loadError);
    }
    if (!m_nistDatabase.open(&loadError)) {
        showError(loadError);
    }

    createLanguageMenu();
    rebuildUi();
}

void MainWindow::createLanguageMenu()
{
#ifdef Q_OS_ANDROID
    return;
#else
    menuBar()->clear();
    QMenu *languageMenu = menuBar()->addMenu(QStringLiteral("Language"));

    QAction *englishAction = languageMenu->addAction(QStringLiteral("English"));
    QAction *chineseAction = languageMenu->addAction(QStringLiteral("Chinese"));
    languageMenu->addSeparator();
    QAction *sourceAction = languageMenu->addAction(QStringLiteral("GitHub"));
    englishAction->setCheckable(true);
    chineseAction->setCheckable(true);
    englishAction->setChecked(m_language == UiLanguage::English);
    chineseAction->setChecked(m_language == UiLanguage::Chinese);

    connect(englishAction, &QAction::triggered, this, [this]() { setLanguage(UiLanguage::English); });
    connect(chineseAction, &QAction::triggered, this, [this]() { setLanguage(UiLanguage::Chinese); });
    connect(sourceAction, &QAction::triggered, this, &MainWindow::openSourceRepository);
#endif
}

void MainWindow::rebuildUi()
{
    setWindowTitle(text("windowTitle"));

    auto *central = new QWidget(this);
    auto *layout = new QVBoxLayout(central);
#ifdef Q_OS_ANDROID
    layout->setContentsMargins(10, 8, 10, 10);
    layout->setSpacing(8);
    layout->addWidget(createAndroidHeader());
#endif

    m_tabs = new QTabWidget(central);
    m_tabs->addTab(createScrollablePage(createSingleElementTab()), text("singleTab"));
    m_tabs->addTab(createScrollablePage(createFormulaMixtureTab()), text("formulaTab"));
    m_tabs->addTab(createScrollablePage(createManualMixtureTab()), text("manualTab"));
    m_tabs->addTab(createScrollablePage(createNistTab()), text("nistTab"));

    layout->addWidget(m_tabs, 1);
    layout->addWidget(createResultsPanel());
    setCentralWidget(central);
}

QWidget *MainWindow::createAndroidHeader()
{
    auto *header = new QWidget(this);
    auto *layout = new QHBoxLayout(header);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(8);

    auto *title = new QLabel(text("windowTitle"), header);
    QFont titleFont = title->font();
    titleFont.setBold(true);
    titleFont.setPointSize(std::max(12, titleFont.pointSize() + 1));
    title->setFont(titleFont);
    title->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);

    auto *languageButton = new QPushButton(header);
    languageButton->setText(m_language == UiLanguage::Chinese
                                ? QStringLiteral("English")
                                : QStringLiteral("中文"));
    languageButton->setMinimumWidth(92);
    connect(languageButton, &QPushButton::clicked, this, [this]() {
        const UiLanguage language = m_language == UiLanguage::Chinese
                                        ? UiLanguage::English
                                        : UiLanguage::Chinese;
        setLanguage(language);
    });

    auto *sourceButton = new QPushButton(QStringLiteral("GitHub"), header);
    sourceButton->setMinimumWidth(86);
    connect(sourceButton, &QPushButton::clicked, this, &MainWindow::openSourceRepository);

    layout->addWidget(title);
    layout->addWidget(languageButton);
    layout->addWidget(sourceButton);
    return header;
}

QWidget *MainWindow::createSingleElementTab()
{
    auto *tab = new QWidget(this);
    auto *layout = new QVBoxLayout(tab);
    auto *form = new QFormLayout();

    m_singleEnergy = makeLineEdit(QStringLiteral("662"), tab);
    m_singleAtomicNumber = makeLineEdit(QStringLiteral("82"), tab);
    m_singleDensity = makeLineEdit(QStringLiteral("11.34"), tab);
    m_singleThickness = makeLineEdit(QStringLiteral("1"), tab);

    form->addRow(text("energy"), m_singleEnergy);
    form->addRow(text("atomicNumber"), m_singleAtomicNumber);
    form->addRow(text("density"), m_singleDensity);
    form->addRow(text("currentThickness"), m_singleThickness);

    auto *button = new QPushButton(text("calculateSingle"), tab);
    connect(button, &QPushButton::clicked, this, &MainWindow::calculateSingleElement);
    auto *exportButton = new QPushButton(text("exportCurve"), tab);
    connect(exportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);

    m_singlePlot = new AttenuationPlot(tab);
    setupPlot(m_singlePlot);

    auto *buttonRow = new QGridLayout();
    buttonRow->addWidget(button, 0, 0);
    buttonRow->addWidget(exportButton, 0, 1);

    layout->addLayout(form);
    layout->addLayout(buttonRow);
    layout->addWidget(m_singlePlot);
    layout->addStretch(1);
    return tab;
}

QWidget *MainWindow::createFormulaMixtureTab()
{
    auto *tab = new QWidget(this);
    auto *layout = new QVBoxLayout(tab);
    auto *form = new QFormLayout();

    m_formulaEnergy = makeLineEdit(QStringLiteral("662"), tab);
    m_formulaInput = makeLineEdit(QStringLiteral("H2O"), tab);
    m_formulaInput->setPlaceholderText(text("formulaPlaceholder"));
    m_formulaDensity = makeLineEdit(QStringLiteral("1"), tab);
    m_formulaThickness = makeLineEdit(QStringLiteral("1"), tab);

    form->addRow(text("energy"), m_formulaEnergy);
    form->addRow(text("formula"), m_formulaInput);
    form->addRow(text("mixtureDensity"), m_formulaDensity);
    form->addRow(text("currentThickness"), m_formulaThickness);

    auto *button = new QPushButton(text("calculateFormula"), tab);
    connect(button, &QPushButton::clicked, this, &MainWindow::calculateFormulaMixture);
    auto *exportButton = new QPushButton(text("exportCurve"), tab);
    connect(exportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);

    m_formulaPlot = new AttenuationPlot(tab);
    setupPlot(m_formulaPlot);

    m_fractionTable = new QTableWidget(0, 3, tab);
    m_fractionTable->setHorizontalHeaderLabels({text("element"),
                                                text("atomicNumber"),
                                                text("massPercent")});
    m_fractionTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    m_fractionTable->setEditTriggers(QAbstractItemView::NoEditTriggers);

    auto *buttonRow = new QGridLayout();
    buttonRow->addWidget(button, 0, 0);
    buttonRow->addWidget(exportButton, 0, 1);

    layout->addLayout(form);
    layout->addLayout(buttonRow);
    layout->addWidget(m_formulaPlot);
    layout->addWidget(m_fractionTable, 1);
    return tab;
}

QWidget *MainWindow::createManualMixtureTab()
{
    auto *tab = new QWidget(this);
    auto *layout = new QVBoxLayout(tab);
    auto *form = new QFormLayout();

    m_manualEnergy = makeLineEdit(QStringLiteral("662"), tab);
    m_manualDensity = makeLineEdit(QStringLiteral("1"), tab);
    m_manualThickness = makeLineEdit(QStringLiteral("1"), tab);
    form->addRow(text("energy"), m_manualEnergy);
    form->addRow(text("mixtureDensity"), m_manualDensity);
    form->addRow(text("currentThickness"), m_manualThickness);

    m_manualTable = new QTableWidget(0, 2, tab);
    m_manualTable->setHorizontalHeaderLabels({text("elementInput"),
                                              text("massPercent")});
    m_manualTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    auto *buttonsLayout = new QGridLayout();
    auto *addButton = new QPushButton(text("addElement"), tab);
    auto *removeButton = new QPushButton(text("removeSelected"), tab);
    auto *calculateButton = new QPushButton(text("calculateManual"), tab);
    auto *exportButton = new QPushButton(text("exportCurve"), tab);
    connect(addButton, &QPushButton::clicked, this, [this]() { addManualRow(); });
    connect(removeButton, &QPushButton::clicked, this, &MainWindow::removeSelectedManualRows);
    connect(calculateButton, &QPushButton::clicked, this, &MainWindow::calculateManualMixture);
    connect(exportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);
    buttonsLayout->addWidget(addButton, 0, 0);
    buttonsLayout->addWidget(removeButton, 0, 1);
    buttonsLayout->addWidget(calculateButton, 0, 2);
    buttonsLayout->addWidget(exportButton, 0, 3);

    addManualRow(QStringLiteral("Pb"), 50.0);
    addManualRow(QStringLiteral("Sn"), 50.0);

    m_manualPlot = new AttenuationPlot(tab);
    setupPlot(m_manualPlot);

    layout->addLayout(form);
    layout->addWidget(m_manualTable, 1);
    layout->addLayout(buttonsLayout);
    layout->addWidget(m_manualPlot);
    return tab;
}

QWidget *MainWindow::createNistTab()
{
    auto *tab = new QWidget(this);
    auto *layout = new QVBoxLayout(tab);

    m_nistModeTabs = new QTabWidget(tab);

    auto *singleTab = new QWidget(m_nistModeTabs);
    auto *singleLayout = new QVBoxLayout(singleTab);
    auto *singleForm = new QFormLayout();
    m_nistSingleEnergy = makeLineEdit(QStringLiteral("662"), singleTab);
    m_nistSingleAtomicNumber = makeLineEdit(QStringLiteral("82"), singleTab);
    m_nistSingleDensity = makeLineEdit(QStringLiteral("11.34"), singleTab);
    m_nistSingleThickness = makeLineEdit(QStringLiteral("1"), singleTab);
    singleForm->addRow(text("energy"), m_nistSingleEnergy);
    singleForm->addRow(text("atomicNumber"), m_nistSingleAtomicNumber);
    singleForm->addRow(text("density"), m_nistSingleDensity);
    singleForm->addRow(text("currentThickness"), m_nistSingleThickness);
    auto *singleButtonRow = new QGridLayout();
    auto *singleCalculateButton = new QPushButton(text("calculateSingle"), singleTab);
    auto *singleExportButton = new QPushButton(text("exportCurve"), singleTab);
    connect(singleCalculateButton, &QPushButton::clicked, this, &MainWindow::calculateNistSingleElement);
    connect(singleExportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);
    singleButtonRow->addWidget(singleCalculateButton, 0, 0);
    singleButtonRow->addWidget(singleExportButton, 0, 1);
    m_nistSinglePlot = new AttenuationPlot(singleTab);
    setupPlot(m_nistSinglePlot);
    singleLayout->addLayout(singleForm);
    singleLayout->addLayout(singleButtonRow);
    singleLayout->addWidget(m_nistSinglePlot);
    singleLayout->addStretch(1);

    auto *formulaTab = new QWidget(m_nistModeTabs);
    auto *formulaLayout = new QVBoxLayout(formulaTab);
    auto *formulaForm = new QFormLayout();
    m_nistFormulaEnergy = makeLineEdit(QStringLiteral("662"), formulaTab);
    m_nistFormulaInput = makeLineEdit(QStringLiteral("H2O"), formulaTab);
    m_nistFormulaInput->setPlaceholderText(text("formulaPlaceholder"));
    m_nistFormulaDensity = makeLineEdit(QStringLiteral("1"), formulaTab);
    m_nistFormulaThickness = makeLineEdit(QStringLiteral("1"), formulaTab);
    formulaForm->addRow(text("energy"), m_nistFormulaEnergy);
    formulaForm->addRow(text("formula"), m_nistFormulaInput);
    formulaForm->addRow(text("mixtureDensity"), m_nistFormulaDensity);
    formulaForm->addRow(text("currentThickness"), m_nistFormulaThickness);
    auto *formulaButtonRow = new QGridLayout();
    auto *formulaCalculateButton = new QPushButton(text("calculateFormula"), formulaTab);
    auto *formulaExportButton = new QPushButton(text("exportCurve"), formulaTab);
    connect(formulaCalculateButton, &QPushButton::clicked, this, &MainWindow::calculateNistFormulaMixture);
    connect(formulaExportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);
    formulaButtonRow->addWidget(formulaCalculateButton, 0, 0);
    formulaButtonRow->addWidget(formulaExportButton, 0, 1);
    m_nistFormulaPlot = new AttenuationPlot(formulaTab);
    setupPlot(m_nistFormulaPlot);
    m_nistFractionTable = new QTableWidget(0, 3, formulaTab);
    m_nistFractionTable->setHorizontalHeaderLabels({text("element"),
                                                    text("atomicNumber"),
                                                    text("massPercent")});
    m_nistFractionTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    m_nistFractionTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    formulaLayout->addLayout(formulaForm);
    formulaLayout->addLayout(formulaButtonRow);
    formulaLayout->addWidget(m_nistFormulaPlot);
    formulaLayout->addWidget(m_nistFractionTable, 1);

    auto *manualTab = new QWidget(m_nistModeTabs);
    auto *manualLayout = new QVBoxLayout(manualTab);
    auto *manualForm = new QFormLayout();
    m_nistManualEnergy = makeLineEdit(QStringLiteral("662"), manualTab);
    m_nistManualDensity = makeLineEdit(QStringLiteral("1"), manualTab);
    m_nistManualThickness = makeLineEdit(QStringLiteral("1"), manualTab);
    manualForm->addRow(text("energy"), m_nistManualEnergy);
    manualForm->addRow(text("mixtureDensity"), m_nistManualDensity);
    manualForm->addRow(text("currentThickness"), m_nistManualThickness);
    m_nistManualTable = new QTableWidget(0, 2, manualTab);
    m_nistManualTable->setHorizontalHeaderLabels({text("elementInput"), text("massPercent")});
    m_nistManualTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    auto *manualButtonRow = new QGridLayout();
    auto *manualAddButton = new QPushButton(text("addElement"), manualTab);
    auto *manualRemoveButton = new QPushButton(text("removeSelected"), manualTab);
    auto *manualCalculateButton = new QPushButton(text("calculateManual"), manualTab);
    auto *manualExportButton = new QPushButton(text("exportCurve"), manualTab);
    connect(manualAddButton, &QPushButton::clicked, this, [this]() { addNistManualRow(); });
    connect(manualRemoveButton, &QPushButton::clicked, this, &MainWindow::removeSelectedNistManualRows);
    connect(manualCalculateButton, &QPushButton::clicked, this, &MainWindow::calculateNistManualMixture);
    connect(manualExportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);
    manualButtonRow->addWidget(manualAddButton, 0, 0);
    manualButtonRow->addWidget(manualRemoveButton, 0, 1);
    manualButtonRow->addWidget(manualCalculateButton, 0, 2);
    manualButtonRow->addWidget(manualExportButton, 0, 3);
    addNistManualRow(QStringLiteral("Pb"), 50.0);
    addNistManualRow(QStringLiteral("Sn"), 50.0);
    m_nistManualPlot = new AttenuationPlot(manualTab);
    setupPlot(m_nistManualPlot);
    manualLayout->addLayout(manualForm);
    manualLayout->addWidget(m_nistManualTable, 1);
    manualLayout->addLayout(manualButtonRow);
    manualLayout->addWidget(m_nistManualPlot);

    auto *materialTab = new QWidget(m_nistModeTabs);
    auto *materialLayout = new QVBoxLayout(materialTab);
    auto *searchRow = new QGridLayout();
    m_nistSearch = makeLineEdit(QStringLiteral("poly"), materialTab);
    m_nistSearch->setPlaceholderText(text("nistSearchPlaceholder"));
    auto *searchButton = new QPushButton(text("nistSearch"), materialTab);
    connect(searchButton, &QPushButton::clicked, this, &MainWindow::searchNistMaterials);
    searchRow->addWidget(new QLabel(text("nistMaterialSearch"), materialTab), 0, 0);
    searchRow->addWidget(m_nistSearch, 0, 1);
    searchRow->addWidget(searchButton, 0, 2);

    m_nistMaterialTable = new QTableWidget(0, 2, materialTab);
    m_nistMaterialTable->setHorizontalHeaderLabels({text("nistMaterial"), text("density")});
    m_nistMaterialTable->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);
    m_nistMaterialTable->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_nistMaterialTable->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_nistMaterialTable->setSelectionMode(QAbstractItemView::SingleSelection);
    connect(m_nistMaterialTable, &QTableWidget::cellClicked, this, [this](int row, int) {
        selectNistMaterial(row);
    });
    connect(m_nistMaterialTable, &QTableWidget::cellDoubleClicked, this, [this](int row, int) {
        selectNistMaterial(row);
    });

    auto *form = new QFormLayout();
    m_nistMaterialName = makeLineEdit(QString(), materialTab);
    m_nistMaterialName->setReadOnly(true);
    m_nistEnergy = makeLineEdit(QStringLiteral("662"), materialTab);
    m_nistDensity = makeLineEdit(QStringLiteral("1"), materialTab);
    m_nistThickness = makeLineEdit(QStringLiteral("1"), materialTab);
    form->addRow(text("nistSelectedMaterial"), m_nistMaterialName);
    form->addRow(text("energy"), m_nistEnergy);
    form->addRow(text("density"), m_nistDensity);
    form->addRow(text("currentThickness"), m_nistThickness);

    auto *buttonRow = new QGridLayout();
    auto *calculateButton = new QPushButton(text("calculateNist"), materialTab);
    auto *exportButton = new QPushButton(text("exportCurve"), materialTab);
    connect(calculateButton, &QPushButton::clicked, this, &MainWindow::calculateNistMaterial);
    connect(exportButton, &QPushButton::clicked, this, &MainWindow::exportCurrentCurve);
    buttonRow->addWidget(calculateButton, 0, 0);
    buttonRow->addWidget(exportButton, 0, 1);

    m_nistPlot = new AttenuationPlot(materialTab);
    setupPlot(m_nistPlot);

    materialLayout->addLayout(searchRow);
    materialLayout->addWidget(m_nistMaterialTable, 1);
    materialLayout->addLayout(form);
    materialLayout->addLayout(buttonRow);
    materialLayout->addWidget(m_nistPlot);

    m_nistModeTabs->addTab(singleTab, text("singleTab"));
    m_nistModeTabs->addTab(formulaTab, text("formulaTab"));
    m_nistModeTabs->addTab(manualTab, text("manualTab"));
    m_nistModeTabs->addTab(materialTab, text("nistStandardMaterialTab"));

    layout->addWidget(m_nistModeTabs);

    searchNistMaterials();
    return tab;
}

QWidget *MainWindow::createResultsPanel()
{
    auto *group = new QGroupBox(text("results"), this);
    auto *layout = new QGridLayout(group);

    m_massCoefficientValue = new QLabel(QStringLiteral("-"), group);
    m_linearCoefficientValue = new QLabel(QStringLiteral("-"), group);
    m_halfValueLayerValue = new QLabel(QStringLiteral("-"), group);
    m_attenuation95Value = new QLabel(QStringLiteral("-"), group);
    m_currentAttenuationValue = new QLabel(QStringLiteral("-"), group);

    layout->addWidget(new QLabel(text("massCoefficient"), group), 0, 0);
    layout->addWidget(m_massCoefficientValue, 0, 1);
    layout->addWidget(new QLabel(text("linearCoefficient"), group), 1, 0);
    layout->addWidget(m_linearCoefficientValue, 1, 1);
    layout->addWidget(new QLabel(text("halfValueLayer"), group), 2, 0);
    layout->addWidget(m_halfValueLayerValue, 2, 1);
    layout->addWidget(new QLabel(text("attenuation95"), group), 3, 0);
    layout->addWidget(m_attenuation95Value, 3, 1);
    layout->addWidget(new QLabel(text("currentAttenuation"), group), 4, 0);
    layout->addWidget(m_currentAttenuationValue, 4, 1);

    return group;
}

QWidget *MainWindow::createScrollablePage(QWidget *content)
{
#ifdef Q_OS_ANDROID
    auto *scrollArea = new QScrollArea(this);
    scrollArea->setWidgetResizable(true);
    scrollArea->setFrameShape(QFrame::NoFrame);
    scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    scrollArea->setWidget(content);
    return scrollArea;
#else
    return content;
#endif
}

void MainWindow::calculateSingleElement()
{
    double energy = 0.0;
    double density = 0.0;
    double thickness = 0.0;
    int atomicNumber = 0;
    if (!readRequiredDouble(m_singleEnergy, &energy)
        || !readRequiredInt(m_singleAtomicNumber, &atomicNumber)
        || !readRequiredDouble(m_singleDensity, &density)
        || !readRequiredDouble(m_singleThickness, &thickness)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateAtomicNumber(atomicNumber) || !validateEnergy(energy) || !validateThickness(thickness)) {
        return;
    }

    try {
        showResult(m_calculator.calculateSingle(atomicNumber, energy, density), thickness);
        m_fractionTable->clearContents();
        m_fractionTable->setRowCount(0);
    } catch (const std::exception &ex) {
        showError(QString::fromLocal8Bit(ex.what()));
    }
}

void MainWindow::calculateFormulaMixture()
{
    double energy = 0.0;
    double density = 0.0;
    double thickness = 0.0;
    if (!readRequiredDouble(m_formulaEnergy, &energy)
        || m_formulaInput->text().trimmed().isEmpty()
        || !readRequiredDouble(m_formulaDensity, &density)
        || !readRequiredDouble(m_formulaThickness, &thickness)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateEnergy(energy) || !validateThickness(thickness)) {
        return;
    }

    QString errorMessage;
    const QVector<MixtureComponent> components =
        FormulaParser::parseMassFractions(m_formulaInput->text(), &errorMessage);
    if (components.isEmpty()) {
        showError(m_language == UiLanguage::English ? text("invalidFormula") : errorMessage);
        return;
    }

    try {
        showMassFractions(components);
        showResult(m_calculator.calculateMixture(components, energy, density), thickness);
    } catch (const std::exception &ex) {
        showError(QString::fromLocal8Bit(ex.what()));
    }
}

void MainWindow::calculateManualMixture()
{
    double energy = 0.0;
    double density = 0.0;
    double thickness = 0.0;
    if (!readRequiredDouble(m_manualEnergy, &energy)
        || !readRequiredDouble(m_manualDensity, &density)
        || !readRequiredDouble(m_manualThickness, &thickness)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateEnergy(energy) || !validateThickness(thickness)) {
        return;
    }

    bool ok = false;
    const QVector<MixtureComponent> components = manualComponents(&ok);
    if (!ok) {
        return;
    }

    try {
        showMassFractions(components);
        showResult(m_calculator.calculateMixture(components, energy, density), thickness);
    } catch (const std::exception &ex) {
        showError(QString::fromLocal8Bit(ex.what()));
    }
}

void MainWindow::calculateNistSingleElement()
{
    double energy = 0.0;
    double density = 0.0;
    double thickness = 0.0;
    int atomicNumber = 0;
    if (!readRequiredDouble(m_nistSingleEnergy, &energy)
        || !readRequiredInt(m_nistSingleAtomicNumber, &atomicNumber)
        || !readRequiredDouble(m_nistSingleDensity, &density)
        || !readRequiredDouble(m_nistSingleThickness, &thickness)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateNistEnergy(energy) || !validateAtomicNumber(atomicNumber) || !validateThickness(thickness)) {
        return;
    }

    AttenuationResult result;
    QString errorMessage;
    if (!m_nistDatabase.calculateSingle(atomicNumber, energy, density, &result, &errorMessage)) {
        showError(errorMessage);
        return;
    }
    showResult(result, thickness);
}

void MainWindow::calculateNistFormulaMixture()
{
    double energy = 0.0;
    double density = 0.0;
    double thickness = 0.0;
    if (!readRequiredDouble(m_nistFormulaEnergy, &energy)
        || !readRequiredDouble(m_nistFormulaDensity, &density)
        || !readRequiredDouble(m_nistFormulaThickness, &thickness)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateNistEnergy(energy) || !validateThickness(thickness)) {
        return;
    }

    QString errorMessage;
    const QVector<MixtureComponent> components =
        FormulaParser::parseMassFractions(m_nistFormulaInput->text(), &errorMessage);
    if (!errorMessage.isEmpty()) {
        showError(errorMessage);
        return;
    }

    AttenuationResult result;
    if (!m_nistDatabase.calculateMixture(components, energy, density, &result, &errorMessage)) {
        showError(errorMessage);
        return;
    }
    showMassFractions(m_nistFractionTable, components);
    showResult(result, thickness);
}

void MainWindow::calculateNistManualMixture()
{
    double energy = 0.0;
    double density = 0.0;
    double thickness = 0.0;
    if (!readRequiredDouble(m_nistManualEnergy, &energy)
        || !readRequiredDouble(m_nistManualDensity, &density)
        || !readRequiredDouble(m_nistManualThickness, &thickness)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateNistEnergy(energy) || !validateThickness(thickness)) {
        return;
    }

    bool ok = false;
    const QVector<MixtureComponent> components = manualComponents(m_nistManualTable, &ok);
    if (!ok) {
        return;
    }

    AttenuationResult result;
    QString errorMessage;
    if (!m_nistDatabase.calculateMixture(components, energy, density, &result, &errorMessage)) {
        showError(errorMessage);
        return;
    }
    showMassFractions(m_nistFractionTable, components);
    showResult(result, thickness);
}

void MainWindow::searchNistMaterials()
{
    if (!m_nistMaterialTable || !m_nistSearch) {
        return;
    }

    QString errorMessage;
    const QVector<NistMaterial> materials =
        m_nistDatabase.searchMaterials(m_nistSearch->text(), &errorMessage);
    if (!errorMessage.isEmpty()) {
        showError(errorMessage);
        return;
    }

    m_nistMaterialTable->clearContents();
    m_nistMaterialTable->setRowCount(materials.size());
    for (int row = 0; row < materials.size(); ++row) {
        m_nistMaterialTable->setItem(row, 0, new QTableWidgetItem(materials[row].name));
        m_nistMaterialTable->setItem(row, 1, new QTableWidgetItem(formatNumber(materials[row].density)));
    }

    if (!materials.isEmpty()) {
        m_nistMaterialTable->selectRow(0);
        selectNistMaterial(0);
    }
}

void MainWindow::selectNistMaterial(int row)
{
    if (!m_nistMaterialTable || row < 0 || row >= m_nistMaterialTable->rowCount()) {
        return;
    }

    const QTableWidgetItem *nameItem = m_nistMaterialTable->item(row, 0);
    const QTableWidgetItem *densityItem = m_nistMaterialTable->item(row, 1);
    if (!nameItem || !densityItem) {
        return;
    }

    m_nistMaterialName->setText(nameItem->text());
    m_nistDensity->setText(densityItem->text());
}

void MainWindow::calculateNistMaterial()
{
    if (!m_nistMaterialName || m_nistMaterialName->text().trimmed().isEmpty()) {
        showError(text("nistNoMaterial"));
        return;
    }

    double energy = 0.0;
    double density = 0.0;
    double thickness = 0.0;
    if (!readRequiredDouble(m_nistEnergy, &energy)
        || !readRequiredDouble(m_nistDensity, &density)
        || !readRequiredDouble(m_nistThickness, &thickness)) {
        showError(text("incomplete"));
        return;
    }
    if (!validateNistEnergy(energy) || !validateThickness(thickness)) {
        return;
    }

    AttenuationResult result;
    QString errorMessage;
    if (!m_nistDatabase.calculateMaterial(m_nistMaterialName->text(), energy, density, &result, &errorMessage)) {
        showError(errorMessage);
        return;
    }

    showResult(result, thickness);
}

void MainWindow::addManualRow(const QString &element, double percent)
{
    auto addRow = [](QTableWidget *table, const QString &elementText, double percentValue) {
        const int row = table->rowCount();
        table->insertRow(row);
        table->setItem(row, 0, new QTableWidgetItem(elementText));
        table->setItem(row, 1, new QTableWidgetItem(percentValue > 0.0 ? formatNumber(percentValue) : QString()));
    };
    addRow(m_manualTable, element, percent);
}

void MainWindow::addNistManualRow(const QString &element, double percent)
{
    const int row = m_nistManualTable->rowCount();
    m_nistManualTable->insertRow(row);
    m_nistManualTable->setItem(row, 0, new QTableWidgetItem(element));
    m_nistManualTable->setItem(row, 1, new QTableWidgetItem(percent > 0.0 ? formatNumber(percent) : QString()));
}

void MainWindow::removeSelectedManualRows()
{
    auto removeRows = [](QTableWidget *table) {
        QSet<int> rowsToRemove;
        QSet<int> percentRowsToClear;

        for (const QModelIndex &index : table->selectionModel()->selectedIndexes()) {
            if (index.column() == 0) {
                rowsToRemove.insert(index.row());
            } else if (index.column() == 1) {
                percentRowsToClear.insert(index.row());
            }
        }

        for (const QModelIndex &index : table->selectionModel()->selectedRows()) {
            rowsToRemove.insert(index.row());
        }

        for (int row : rowsToRemove) {
            percentRowsToClear.remove(row);
        }

        for (int row : percentRowsToClear) {
            QTableWidgetItem *item = table->item(row, 1);
            if (item) {
                item->setText(QString());
            }
        }

        QList<int> rows = rowsToRemove.values();
        std::sort(rows.begin(), rows.end(), std::greater<int>());
        for (int row : rows) {
            table->removeRow(row);
        }
    };
    removeRows(m_manualTable);
}

void MainWindow::removeSelectedNistManualRows()
{
    QSet<int> rowsToRemove;
    QSet<int> percentRowsToClear;

    for (const QModelIndex &index : m_nistManualTable->selectionModel()->selectedIndexes()) {
        if (index.column() == 0) {
            rowsToRemove.insert(index.row());
        } else if (index.column() == 1) {
            percentRowsToClear.insert(index.row());
        }
    }

    for (const QModelIndex &index : m_nistManualTable->selectionModel()->selectedRows()) {
        rowsToRemove.insert(index.row());
    }

    for (int row : rowsToRemove) {
        percentRowsToClear.remove(row);
    }

    for (int row : percentRowsToClear) {
        QTableWidgetItem *item = m_nistManualTable->item(row, 1);
        if (item) {
            item->setText(QString());
        }
    }

    QList<int> rows = rowsToRemove.values();
    std::sort(rows.begin(), rows.end(), std::greater<int>());
    for (int row : rows) {
        m_nistManualTable->removeRow(row);
    }
}

void MainWindow::setLanguage(UiLanguage language)
{
    if (m_language == language) {
        return;
    }
    m_language = language;
    createLanguageMenu();
    rebuildUi();
}

void MainWindow::openSourceRepository()
{
    QDesktopServices::openUrl(QUrl(QStringLiteral("https://github.com/myfatenine/Gamma-attenuation-calculator")));
}

bool MainWindow::readRequiredDouble(QLineEdit *edit, double *value)
{
    const QString input = edit->text().trimmed();
    if (input.isEmpty()) {
        return false;
    }

    bool ok = false;
    const double parsed = input.toDouble(&ok);
    if (!ok) {
        return false;
    }
    *value = parsed;
    return true;
}

bool MainWindow::readRequiredInt(QLineEdit *edit, int *value)
{
    const QString input = edit->text().trimmed();
    if (input.isEmpty()) {
        return false;
    }

    bool ok = false;
    const int parsed = input.toInt(&ok);
    if (!ok) {
        return false;
    }
    *value = parsed;
    return true;
}

bool MainWindow::validateEnergy(double energyKeV)
{
    if (energyKeV < 100.0 || energyKeV > 20000.0) {
        showError(text("energyRange"));
        return false;
    }
    return true;
}

bool MainWindow::validateNistEnergy(double energyKeV)
{
    if (energyKeV < 1.0 || energyKeV > 20000.0) {
        showError(text("nistEnergyRange"));
        return false;
    }
    return true;
}

bool MainWindow::validateAtomicNumber(int atomicNumber)
{
    if (atomicNumber < 1 || atomicNumber > 92) {
        showError(text("atomicRange"));
        return false;
    }
    return true;
}

bool MainWindow::validateThickness(double thicknessCm)
{
    if (thicknessCm < 0.0 || !std::isfinite(thicknessCm)) {
        showError(text("thicknessRange"));
        return false;
    }
    return true;
}

void MainWindow::setupPlot(AttenuationPlot *plot)
{
    plot->setLanguageText(text("plotTitle"),
                          text("plotXAxis"),
                          text("plotYAxis"),
                          text("plotEmpty"),
                          text("plotEnd"),
                          text("plotHalf"),
                          text("plot95"));
}

AttenuationPlot *MainWindow::currentPlot() const
{
    if (m_tabs->currentIndex() == 0) {
        return m_singlePlot;
    }
    if (m_tabs->currentIndex() == 1) {
        return m_formulaPlot;
    }
    if (m_tabs->currentIndex() == 2) {
        return m_manualPlot;
    }
    if (m_tabs->currentIndex() == 3) {
        if (!m_nistModeTabs) {
            return m_nistPlot;
        }
        if (m_nistModeTabs->currentIndex() == 0) {
            return m_nistSinglePlot;
        }
        if (m_nistModeTabs->currentIndex() == 1) {
            return m_nistFormulaPlot;
        }
        if (m_nistModeTabs->currentIndex() == 2) {
            return m_nistManualPlot;
        }
        return m_nistPlot;
    }
    return nullptr;
}

void MainWindow::updateCurrentPlot(const AttenuationResult &result)
{
    AttenuationPlot *plot = currentPlot();
    if (plot) {
        plot->setLinearCoefficient(result.linearCoefficient);
    }
}

void MainWindow::exportCurrentCurve()
{
    AttenuationPlot *plot = currentPlot();
    if (!plot || !plot->hasCurve()) {
        showError(text("plotNoData"));
        return;
    }

    QString filePath = QFileDialog::getSaveFileName(this,
                                                    text("exportCaption"),
                                                    QStringLiteral("attenuation_curve.csv"),
                                                    QStringLiteral("CSV files (*.csv)"));
    if (filePath.isEmpty()) {
        return;
    }
    if (!filePath.endsWith(QStringLiteral(".csv"), Qt::CaseInsensitive)) {
        filePath += QStringLiteral(".csv");
    }

    QString errorMessage;
    if (!plot->exportCsv(filePath, &errorMessage)) {
        showError(text("exportFailed").arg(errorMessage));
        return;
    }
    QMessageBox::information(this, text("exportDoneTitle"), text("exportDone").arg(filePath));
}

void MainWindow::showResult(const AttenuationResult &result, double thicknessCm)
{
    if (result.linearCoefficient <= 0.0 || !std::isfinite(result.linearCoefficient)) {
        showError(text("invalidLinearCoefficient"));
        return;
    }

    m_massCoefficientValue->setText(formatNumber(result.massCoefficient));
    m_linearCoefficientValue->setText(formatNumber(result.linearCoefficient));
    m_halfValueLayerValue->setText(formatNumber(result.halfValueLayer));
    m_attenuation95Value->setText(formatNumber(result.attenuation95Thickness));
    const double currentAttenuation =
        (1.0 - std::exp(-result.linearCoefficient * thicknessCm)) * 100.0;
    m_currentAttenuationValue->setText(formatNumber(currentAttenuation));
    updateCurrentPlot(result);
}

void MainWindow::showMassFractions(const QVector<MixtureComponent> &components)
{
    showMassFractions(m_fractionTable, components);
}

void MainWindow::showMassFractions(QTableWidget *table, const QVector<MixtureComponent> &components)
{
    if (!table) {
        return;
    }

    table->clearContents();
    table->setRowCount(components.size());
    for (int row = 0; row < components.size(); ++row) {
        const MixtureComponent &component = components[row];
        const ElementInfo *element = AttenuationCalculator::elementByAtomicNumber(component.atomicNumber);
        table->setItem(row, 0, new QTableWidgetItem(QString::fromLatin1(element->symbol)));
        table->setItem(row, 1, new QTableWidgetItem(QString::number(component.atomicNumber)));
        table->setItem(row, 2, new QTableWidgetItem(formatNumber(component.massFraction * 100.0)));
    }
}

void MainWindow::showError(const QString &message)
{
    QMessageBox::warning(this, QStringLiteral("ERROR"), message);
}

QVector<MixtureComponent> MainWindow::manualComponents(bool *ok)
{
    return manualComponents(m_manualTable, ok);
}

QVector<MixtureComponent> MainWindow::manualComponents(QTableWidget *table, bool *ok)
{
    *ok = false;
    QMap<int, double> percentByElement;
    double percentSum = 0.0;

    for (int row = 0; row < table->rowCount(); ++row) {
        const QTableWidgetItem *elementItem = table->item(row, 0);
        const QTableWidgetItem *percentItem = table->item(row, 1);
        const QString elementText = elementItem ? elementItem->text().trimmed() : QString();
        const QString percentText = percentItem ? percentItem->text().trimmed() : QString();
        if (elementText.isEmpty() && percentText.isEmpty()) {
            continue;
        }

        const ElementInfo *element = parseElementText(elementText);
        if (!element) {
            showError(text("manualElementInvalid").arg(row + 1));
            return {};
        }

        bool numberOk = false;
        const double percent = percentText.toDouble(&numberOk);
        if (!numberOk || percent < 0.0 || percent > 100.0) {
            showError(text("manualPercentInvalid").arg(row + 1));
            return {};
        }

        percentByElement[element->atomicNumber] += percent;
        percentSum += percent;
    }

    if (percentByElement.isEmpty()) {
        showError(text("manualEmpty"));
        return {};
    }
    if (std::fabs(percentSum - 100.0) > 0.01) {
        showError(text("manualSum").arg(formatNumber(percentSum)));
        return {};
    }

    QVector<MixtureComponent> components;
    for (auto it = percentByElement.cbegin(); it != percentByElement.cend(); ++it) {
        components.push_back({it.key(), it.value() / 100.0});
    }
    *ok = true;
    return components;
}

QString MainWindow::text(const char *key) const
{
    const QString id = QString::fromLatin1(key);
    const bool english = m_language == UiLanguage::English;

    if (id == QStringLiteral("windowTitle")) {
        return QStringLiteral("Gamma attenuation calculator");
    }
    if (id == QStringLiteral("singleTab")) {
        return english ? QStringLiteral("Single element") : QStringLiteral("单元素");
    }
    if (id == QStringLiteral("formulaTab")) {
        return english ? QStringLiteral("Formula mixture") : QStringLiteral("分子式混合物");
    }
    if (id == QStringLiteral("manualTab")) {
        return english ? QStringLiteral("Manual mixture") : QStringLiteral("手动百分比混合物");
    }
    if (id == QStringLiteral("nistTab")) {
        return QStringLiteral("NIST");
    }
    if (id == QStringLiteral("nistStandardMaterialTab")) {
        return english ? QStringLiteral("Standard material") : QStringLiteral("标准材料");
    }
    if (id == QStringLiteral("energy")) {
        return english ? QStringLiteral("Energy (keV)") : QStringLiteral("能量 (keV)");
    }
    if (id == QStringLiteral("atomicNumber")) {
        return english ? QStringLiteral("Atomic number") : QStringLiteral("原子序数");
    }
    if (id == QStringLiteral("density")) {
        return english ? QStringLiteral("Material density (g/cm^3)") : QStringLiteral("材料密度 (g/cm^3)");
    }
    if (id == QStringLiteral("currentThickness")) {
        return english ? QStringLiteral("Current thickness (cm)") : QStringLiteral("当前厚度 (cm)");
    }
    if (id == QStringLiteral("nistMaterialSearch")) {
        return english ? QStringLiteral("Standard material") : QStringLiteral("标准材料");
    }
    if (id == QStringLiteral("nistSearchPlaceholder")) {
        return english ? QStringLiteral("Examples: poly, concrete, bone")
                       : QStringLiteral("例如：poly、concrete、bone");
    }
    if (id == QStringLiteral("nistSearch")) {
        return english ? QStringLiteral("Search") : QStringLiteral("查找");
    }
    if (id == QStringLiteral("nistMaterial")) {
        return english ? QStringLiteral("NIST material") : QStringLiteral("NIST 材料");
    }
    if (id == QStringLiteral("nistSelectedMaterial")) {
        return english ? QStringLiteral("Selected material") : QStringLiteral("选中材料");
    }
    if (id == QStringLiteral("mixtureDensity")) {
        return english ? QStringLiteral("Mixture density (g/cm^3)") : QStringLiteral("混合物密度 (g/cm^3)");
    }
    if (id == QStringLiteral("formula")) {
        return english ? QStringLiteral("Molecular formula") : QStringLiteral("分子式");
    }
    if (id == QStringLiteral("formulaPlaceholder")) {
        return english ? QStringLiteral("Examples: H2O, CaCO3, Fe2(SO4)3, CuSO4·5H2O")
                       : QStringLiteral("例如：H2O、CaCO3、Fe2(SO4)3、CuSO4·5H2O");
    }
    if (id == QStringLiteral("calculateSingle")) {
        return english ? QStringLiteral("begin to calculate") : QStringLiteral("开始计算");
    }
    if (id == QStringLiteral("calculateFormula")) {
        return english ? QStringLiteral("begin to calculate") : QStringLiteral("开始计算");
    }
    if (id == QStringLiteral("calculateManual")) {
        return english ? QStringLiteral("begin to calculate") : QStringLiteral("开始计算");
    }
    if (id == QStringLiteral("calculateNist")) {
        return english ? QStringLiteral("begin to calculate") : QStringLiteral("开始计算");
    }
    if (id == QStringLiteral("element")) {
        return english ? QStringLiteral("Element") : QStringLiteral("元素");
    }
    if (id == QStringLiteral("elementInput")) {
        return english ? QStringLiteral("Element symbol or atomic number") : QStringLiteral("元素符号或原子序数");
    }
    if (id == QStringLiteral("massPercent")) {
        return english ? QStringLiteral("Mass percentage (%)") : QStringLiteral("质量百分比 (%)");
    }
    if (id == QStringLiteral("addElement")) {
        return english ? QStringLiteral("Add element") : QStringLiteral("添加元素");
    }
    if (id == QStringLiteral("removeSelected")) {
        return english ? QStringLiteral("Remove selected") : QStringLiteral("删除选中");
    }
    if (id == QStringLiteral("results")) {
        return english ? QStringLiteral("Calculation results") : QStringLiteral("计算结果");
    }
    if (id == QStringLiteral("massCoefficient")) {
        return english ? QStringLiteral("Gamma ray mass attenuation coefficient (cm^2/g)")
                       : QStringLiteral("γ质量衰减系数 (cm^2/g)");
    }
    if (id == QStringLiteral("linearCoefficient")) {
        return english ? QStringLiteral("Gamma ray line attenuation coefficient (1/cm)")
                       : QStringLiteral("γ线衰减系数 (1/cm)");
    }
    if (id == QStringLiteral("halfValueLayer")) {
        return english ? QStringLiteral("Gamma ray half-attenuation thickness (cm)")
                       : QStringLiteral("半衰减厚度 (cm)");
    }
    if (id == QStringLiteral("attenuation95")) {
        return english ? QStringLiteral("Gamma ray 95% attenuation thickness (cm)")
                       : QStringLiteral("95% 衰减厚度 (cm)");
    }
    if (id == QStringLiteral("currentAttenuation")) {
        return english ? QStringLiteral("Current thickness attenuation rate (%)")
                       : QStringLiteral("当前厚度衰减率 (%)");
    }
    if (id == QStringLiteral("incomplete")) {
        return english ? QStringLiteral("Please enter all required data!")
                       : QStringLiteral("请将数据输入完整！");
    }
    if (id == QStringLiteral("atomicRange")) {
        return english ? QStringLiteral("The supported atomic number range is 1 to 92")
                       : QStringLiteral("支持原子序数范围为1到92");
    }
    if (id == QStringLiteral("energyRange")) {
        return english ? QStringLiteral("The supported energy range is 100~20000keV")
                       : QStringLiteral("支持能量范围为100~20000keV");
    }
    if (id == QStringLiteral("thicknessRange")) {
        return english ? QStringLiteral("Current thickness should be 0 cm or greater.")
                       : QStringLiteral("当前厚度应大于或等于 0 cm。");
    }
    if (id == QStringLiteral("nistEnergyRange")) {
        return english ? QStringLiteral("The supported NIST energy range is 1~20000keV.")
                       : QStringLiteral("NIST 支持的能量范围为 1~20000 keV。");
    }
    if (id == QStringLiteral("nistNoMaterial")) {
        return english ? QStringLiteral("Please select a NIST material first.")
                       : QStringLiteral("请先选择一个 NIST 标准材料。");
    }
    if (id == QStringLiteral("invalidFormula")) {
        return QStringLiteral("Please enter a valid molecular formula.");
    }
    if (id == QStringLiteral("invalidLinearCoefficient")) {
        return english ? QStringLiteral("The calculated line attenuation coefficient is invalid. Please check the input data.")
                       : QStringLiteral("计算得到的线衰减系数无效，请检查输入数据。");
    }
    if (id == QStringLiteral("manualElementInvalid")) {
        return english ? QStringLiteral("Row %1 has an invalid element. Enter an element symbol or atomic number from 1 to 92.")
                       : QStringLiteral("第 %1 行元素无效，请输入元素符号或 1-92 的原子序数。");
    }
    if (id == QStringLiteral("manualPercentInvalid")) {
        return english ? QStringLiteral("Row %1 has an invalid mass percentage.")
                       : QStringLiteral("第 %1 行质量百分比无效。");
    }
    if (id == QStringLiteral("manualEmpty")) {
        return english ? QStringLiteral("Enter at least one element percentage.")
                       : QStringLiteral("请至少输入一个元素百分比。");
    }
    if (id == QStringLiteral("manualSum")) {
        return english ? QStringLiteral("The manual mass percentages should sum to 100%. Current total: %1%.")
                       : QStringLiteral("手动输入的质量百分比总和应为 100%，当前为 %1%。");
    }
    if (id == QStringLiteral("plotTitle")) {
        return english ? QStringLiteral("Attenuation versus thickness")
                       : QStringLiteral("衰减率随厚度变化曲线");
    }
    if (id == QStringLiteral("plotXAxis")) {
        return english ? QStringLiteral("Thickness (cm)")
                       : QStringLiteral("厚度 (cm)");
    }
    if (id == QStringLiteral("plotYAxis")) {
        return english ? QStringLiteral("Attenuation (%)")
                       : QStringLiteral("衰减率 (%)");
    }
    if (id == QStringLiteral("plotEmpty")) {
        return english ? QStringLiteral("Click calculate to draw the curve")
                       : QStringLiteral("点击开始计算后绘制曲线");
    }
    if (id == QStringLiteral("plotEnd")) {
        return english ? QStringLiteral("99% attenuation")
                       : QStringLiteral("99% 衰减");
    }
    if (id == QStringLiteral("plotHalf")) {
        return english ? QStringLiteral("HVL")
                       : QStringLiteral("半衰减");
    }
    if (id == QStringLiteral("plot95")) {
        return english ? QStringLiteral("95%")
                       : QStringLiteral("95%");
    }
    if (id == QStringLiteral("exportCurve")) {
        return english ? QStringLiteral("Export CSV")
                       : QStringLiteral("导出 CSV");
    }
    if (id == QStringLiteral("plotNoData")) {
        return english ? QStringLiteral("Please calculate a curve before exporting.")
                       : QStringLiteral("请先计算生成曲线后再导出。");
    }
    if (id == QStringLiteral("exportCaption")) {
        return english ? QStringLiteral("Export attenuation curve")
                       : QStringLiteral("导出衰减曲线");
    }
    if (id == QStringLiteral("exportFailed")) {
        return english ? QStringLiteral("Failed to export CSV: %1")
                       : QStringLiteral("导出 CSV 失败：%1");
    }
    if (id == QStringLiteral("exportDoneTitle")) {
        return english ? QStringLiteral("Export complete")
                       : QStringLiteral("导出完成");
    }
    if (id == QStringLiteral("exportDone")) {
        return english ? QStringLiteral("Curve data was exported to:\n%1")
                       : QStringLiteral("曲线数据已导出到：\n%1");
    }

    return id;
}

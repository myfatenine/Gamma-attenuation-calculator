#pragma once

#include "AttenuationCalculator.h"
#include "NistDatabase.h"

#include <QMainWindow>

class AttenuationPlot;
class QLabel;
class QLineEdit;
class QTableWidget;
class QTabWidget;
class QWidget;

enum class UiLanguage {
    Chinese,
    English
};

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);

private:
    void createLanguageMenu();
    void rebuildUi();
    QWidget *createAndroidHeader();
    QWidget *createSingleElementTab();
    QWidget *createFormulaMixtureTab();
    QWidget *createManualMixtureTab();
    QWidget *createNistTab();
    QWidget *createResultsPanel();
    QWidget *createScrollablePage(QWidget *content);

    void calculateSingleElement();
    void calculateFormulaMixture();
    void calculateManualMixture();
    void calculateNistSingleElement();
    void calculateNistFormulaMixture();
    void calculateNistManualMixture();
    void searchNistMaterials();
    void selectNistMaterial(int row);
    void calculateNistMaterial();
    void addManualRow(const QString &element = QString(), double percent = 0.0);
    void addNistManualRow(const QString &element = QString(), double percent = 0.0);
    void removeSelectedManualRows();
    void removeSelectedNistManualRows();
    void setLanguage(UiLanguage language);
    void openSourceRepository();

    bool readRequiredDouble(QLineEdit *edit, double *value);
    bool readRequiredInt(QLineEdit *edit, int *value);
    bool validateEnergy(double energyKeV);
    bool validateNistEnergy(double energyKeV);
    bool validateAtomicNumber(int atomicNumber);
    bool validateThickness(double thicknessCm);

    void setupPlot(AttenuationPlot *plot);
    AttenuationPlot *currentPlot() const;
    void updateCurrentPlot(const AttenuationResult &result);
    void exportCurrentCurve();
    void showResult(const AttenuationResult &result, double thicknessCm);
    void showMassFractions(const QVector<MixtureComponent> &components);
    void showMassFractions(QTableWidget *table, const QVector<MixtureComponent> &components);
    void showError(const QString &message);
    QVector<MixtureComponent> manualComponents(bool *ok);
    QVector<MixtureComponent> manualComponents(QTableWidget *table, bool *ok);
    QString text(const char *key) const;

    AttenuationCalculator m_calculator;
    NistDatabase m_nistDatabase;
    UiLanguage m_language = UiLanguage::Chinese;

    QTabWidget *m_tabs = nullptr;
    QLineEdit *m_singleEnergy = nullptr;
    QLineEdit *m_singleAtomicNumber = nullptr;
    QLineEdit *m_singleDensity = nullptr;
    QLineEdit *m_singleThickness = nullptr;
    AttenuationPlot *m_singlePlot = nullptr;

    QLineEdit *m_formulaEnergy = nullptr;
    QLineEdit *m_formulaInput = nullptr;
    QLineEdit *m_formulaDensity = nullptr;
    QLineEdit *m_formulaThickness = nullptr;
    QTableWidget *m_fractionTable = nullptr;
    AttenuationPlot *m_formulaPlot = nullptr;

    QLineEdit *m_manualEnergy = nullptr;
    QLineEdit *m_manualDensity = nullptr;
    QLineEdit *m_manualThickness = nullptr;
    QTableWidget *m_manualTable = nullptr;
    AttenuationPlot *m_manualPlot = nullptr;

    QTabWidget *m_nistModeTabs = nullptr;
    QLineEdit *m_nistSingleEnergy = nullptr;
    QLineEdit *m_nistSingleAtomicNumber = nullptr;
    QLineEdit *m_nistSingleDensity = nullptr;
    QLineEdit *m_nistSingleThickness = nullptr;
    AttenuationPlot *m_nistSinglePlot = nullptr;

    QLineEdit *m_nistFormulaEnergy = nullptr;
    QLineEdit *m_nistFormulaInput = nullptr;
    QLineEdit *m_nistFormulaDensity = nullptr;
    QLineEdit *m_nistFormulaThickness = nullptr;
    QTableWidget *m_nistFractionTable = nullptr;
    AttenuationPlot *m_nistFormulaPlot = nullptr;

    QLineEdit *m_nistManualEnergy = nullptr;
    QLineEdit *m_nistManualDensity = nullptr;
    QLineEdit *m_nistManualThickness = nullptr;
    QTableWidget *m_nistManualTable = nullptr;
    AttenuationPlot *m_nistManualPlot = nullptr;

    QLineEdit *m_nistSearch = nullptr;
    QTableWidget *m_nistMaterialTable = nullptr;
    QLineEdit *m_nistMaterialName = nullptr;
    QLineEdit *m_nistEnergy = nullptr;
    QLineEdit *m_nistDensity = nullptr;
    QLineEdit *m_nistThickness = nullptr;
    AttenuationPlot *m_nistPlot = nullptr;

    QLabel *m_massCoefficientValue = nullptr;
    QLabel *m_linearCoefficientValue = nullptr;
    QLabel *m_halfValueLayerValue = nullptr;
    QLabel *m_attenuation95Value = nullptr;
    QLabel *m_currentAttenuationValue = nullptr;
};

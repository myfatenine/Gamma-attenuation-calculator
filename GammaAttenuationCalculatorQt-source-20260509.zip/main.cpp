#include "MainWindow.h"

#include <QApplication>

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
#endif

    QApplication app(argc, argv);

    MainWindow window;
#ifdef Q_OS_ANDROID
    window.showMaximized();
#else
    window.show();
#endif

    return app.exec();
}

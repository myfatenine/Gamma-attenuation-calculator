# Gamma Attenuation Calculator Qt

Windows x64 portable release package.

## Run

Double-click `GammaAttenuationCalculatorQt.exe`.

This package includes the required Qt runtime files, `data.csv`, and the MSVC runtime DLLs used by the release build.

## Features

- Single-element gamma-ray attenuation calculation.
- Mixture calculation from molecular formula.
- Mixture calculation from manually entered element mass percentages.
- Chinese and English UI.
- Attenuation curve up to 99% attenuation.
- Half-value layer and 95% attenuation thickness markers.
- CSV export for the attenuation curve.

## CSV Export Columns

- `type`
- `thickness_cm`
- `attenuation_percent`
- `remaining_percent`

## Notes

Keep `data.csv` in the same folder as `GammaAttenuationCalculatorQt.exe`.

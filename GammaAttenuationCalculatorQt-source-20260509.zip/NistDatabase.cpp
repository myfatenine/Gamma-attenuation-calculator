#include "NistDatabase.h"

#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QIODevice>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QStandardPaths>
#include <QVariant>

#include <cmath>

namespace {

const char *kConnectionName = "nist_gamma_attenuation";
const char *kDatabaseFileName = "NISTElementsGammaAttenuation.db";
const char *kDatabaseResourcePath = ":/nist/NISTElementsGammaAttenuation.db";

QString sqlErrorText(const QSqlQuery &query)
{
    return query.lastError().text();
}

QString sqlErrorText(const QSqlDatabase &database)
{
    return database.lastError().text();
}

QByteArray fileHash(QFile *file)
{
    if (!file->open(QIODevice::ReadOnly)) {
        return {};
    }
    const QByteArray hash = QCryptographicHash::hash(file->readAll(), QCryptographicHash::Sha256);
    file->close();
    return hash;
}

} // namespace

bool NistDatabase::open(QString *errorMessage)
{
    m_connectionName = QString::fromLatin1(kConnectionName);

    if (QSqlDatabase::contains(m_connectionName)) {
        QSqlDatabase existing = QSqlDatabase::database(m_connectionName);
        if (existing.isOpen()) {
            return true;
        }
    }

    const QString path = databasePath(errorMessage);
    if (path.isEmpty()) {
        return false;
    }

    QSqlDatabase database = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), m_connectionName);
    database.setDatabaseName(path);
    if (!database.open()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Failed to open NIST database: %1").arg(sqlErrorText(database));
        }
        return false;
    }

    return true;
}

bool NistDatabase::isOpen() const
{
    return !m_connectionName.isEmpty()
           && QSqlDatabase::contains(m_connectionName)
           && QSqlDatabase::database(m_connectionName).isOpen();
}

QVector<NistMaterial> NistDatabase::searchMaterials(const QString &query, QString *errorMessage) const
{
    QVector<NistMaterial> materials;
    if (!isOpen()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NIST database is not open.");
        }
        return materials;
    }

    QSqlQuery sql(QSqlDatabase::database(m_connectionName));
    const QString trimmed = query.trimmed();
    if (trimmed.isEmpty()) {
        sql.prepare(QStringLiteral("SELECT name, density FROM materials ORDER BY name LIMIT 80"));
    } else {
        sql.prepare(QStringLiteral("SELECT name, density FROM materials "
                                   "WHERE lower(name) LIKE lower(:query) "
                                   "ORDER BY name LIMIT 80"));
        sql.bindValue(QStringLiteral(":query"), QStringLiteral("%") + trimmed + QStringLiteral("%"));
    }

    if (!sql.exec()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Failed to search NIST materials: %1").arg(sqlErrorText(sql));
        }
        return materials;
    }

    while (sql.next()) {
        materials.push_back({sql.value(0).toString(), sql.value(1).toDouble()});
    }
    return materials;
}

bool NistDatabase::materialByName(const QString &name, NistMaterial *material, QString *errorMessage) const
{
    if (!isOpen()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NIST database is not open.");
        }
        return false;
    }

    QSqlQuery sql(QSqlDatabase::database(m_connectionName));
    sql.prepare(QStringLiteral("SELECT name, density FROM materials WHERE name = :name LIMIT 1"));
    sql.bindValue(QStringLiteral(":name"), name);
    if (!sql.exec() || !sql.next()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to find NIST material: %1").arg(name);
        }
        return false;
    }

    if (material) {
        material->name = sql.value(0).toString();
        material->density = sql.value(1).toDouble();
    }
    return true;
}

bool NistDatabase::massAttenuationCoefficient(int atomicNumber,
                                              double energyKeV,
                                              double *coefficient,
                                              QString *errorMessage) const
{
    QString tableName;
    if (!elementTableName(atomicNumber, &tableName, errorMessage)) {
        return false;
    }
    return tableMassAttenuationCoefficient(tableName, energyKeV, coefficient, errorMessage);
}

bool NistDatabase::calculateSingle(int atomicNumber,
                                   double energyKeV,
                                   double density,
                                   AttenuationResult *result,
                                   QString *errorMessage) const
{
    if (!result) {
        return false;
    }

    double coefficient = 0.0;
    if (!massAttenuationCoefficient(atomicNumber, energyKeV, &coefficient, errorMessage)) {
        return false;
    }

    fillResult(coefficient, density, result);
    return true;
}

bool NistDatabase::calculateMixture(const QVector<MixtureComponent> &components,
                                    double energyKeV,
                                    double density,
                                    AttenuationResult *result,
                                    QString *errorMessage) const
{
    if (!result) {
        return false;
    }
    if (components.isEmpty()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NIST mixture is empty.");
        }
        return false;
    }

    double mixtureCoefficient = 0.0;
    for (const MixtureComponent &component : components) {
        double coefficient = 0.0;
        if (!massAttenuationCoefficient(component.atomicNumber, energyKeV, &coefficient, errorMessage)) {
            return false;
        }
        mixtureCoefficient += component.massFraction * coefficient;
    }

    fillResult(mixtureCoefficient, density, result);
    return true;
}

bool NistDatabase::calculateMaterial(const QString &name,
                                     double energyKeV,
                                     double density,
                                     AttenuationResult *result,
                                     QString *errorMessage) const
{
    if (!isOpen()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NIST database is not open.");
        }
        return false;
    }
    if (!result) {
        return false;
    }

    double massCoefficient = 0.0;
    if (!tableMassAttenuationCoefficient(name, energyKeV, &massCoefficient, errorMessage)) {
        return false;
    }

    fillResult(massCoefficient, density, result);
    return true;
}

QString NistDatabase::databasePath(QString *errorMessage) const
{
    const QString writableDir =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    if (writableDir.isEmpty()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to find an application data directory.");
        }
        return QString();
    }

    QDir dir(writableDir);
    if (!dir.exists() && !dir.mkpath(QStringLiteral("."))) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to create application data directory: %1").arg(writableDir);
        }
        return QString();
    }

    QFile source(QString::fromLatin1(kDatabaseResourcePath));
    const QByteArray sourceHash = fileHash(&source);
    if (sourceHash.isEmpty()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to open embedded NIST database resource.");
        }
        return QString();
    }

    const QString targetPath = dir.filePath(QString::fromLatin1(kDatabaseFileName));
    QFile existing(targetPath);
    if (QFile::exists(targetPath) && QFileInfo(targetPath).size() > 0
        && fileHash(&existing) == sourceHash) {
        return targetPath;
    }

    if (!source.open(QIODevice::ReadOnly)) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to reopen embedded NIST database resource.");
        }
        return QString();
    }

    QFile target(targetPath);
    if (!target.open(QIODevice::WriteOnly | QIODevice::Truncate)) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to write NIST database copy: %1").arg(targetPath);
        }
        return QString();
    }

    target.write(source.readAll());
    source.close();
    target.close();
    return targetPath;
}

bool NistDatabase::elementTableName(int atomicNumber, QString *tableName, QString *errorMessage) const
{
    if (!isOpen()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NIST database is not open.");
        }
        return false;
    }

    QSqlQuery sql(QSqlDatabase::database(m_connectionName));
    sql.prepare(QStringLiteral("SELECT name FROM elements WHERE atom_number = :atomicNumber LIMIT 1"));
    sql.bindValue(QStringLiteral(":atomicNumber"), atomicNumber);
    if (!sql.exec() || !sql.next()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Unable to find NIST element table for atomic number %1.")
                                .arg(atomicNumber);
        }
        return false;
    }

    if (tableName) {
        *tableName = sql.value(0).toString();
    }
    return true;
}

bool NistDatabase::tableMassAttenuationCoefficient(const QString &tableName,
                                                   double energyKeV,
                                                   double *coefficient,
                                                   QString *errorMessage) const
{
    if (!isOpen()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NIST database is not open.");
        }
        return false;
    }
    if (!coefficient) {
        return false;
    }

    const double energyMeV = energyKeV / 1000.0;
    QVector<double> energies;
    QVector<double> coefficients;

    QSqlQuery sql(QSqlDatabase::database(m_connectionName));
    const QString statement = QStringLiteral("SELECT energy, attencoeff FROM %1 ORDER BY energy")
                                  .arg(quoteIdentifier(tableName));
    if (!sql.exec(statement)) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("Failed to read NIST attenuation table for %1: %2")
                                .arg(tableName, sqlErrorText(sql));
        }
        return false;
    }

    while (sql.next()) {
        energies.push_back(sql.value(0).toDouble());
        coefficients.push_back(sql.value(1).toDouble());
    }

    if (!interpolateMassCoefficient(energies, coefficients, energyMeV, coefficient)) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("NIST energy range is 1 keV to 20 MeV.");
        }
        return false;
    }

    return true;
}

void NistDatabase::fillResult(double massCoefficient, double density, AttenuationResult *result)
{
    result->massCoefficient = massCoefficient;
    result->linearCoefficient = massCoefficient * density;
    result->halfValueLayer = std::log(2.0) / result->linearCoefficient;
    result->attenuation95Thickness = std::log(20.0) / result->linearCoefficient;
}

QString NistDatabase::quoteIdentifier(const QString &identifier)
{
    QString escaped = identifier;
    escaped.replace(QStringLiteral("\""), QStringLiteral("\"\""));
    return QStringLiteral("\"%1\"").arg(escaped);
}

bool NistDatabase::interpolateMassCoefficient(const QVector<double> &energiesMeV,
                                              const QVector<double> &coefficients,
                                              double energyMeV,
                                              double *coefficient)
{
    if (energiesMeV.isEmpty() || energiesMeV.size() != coefficients.size()) {
        return false;
    }
    if (energyMeV < energiesMeV.first() || energyMeV > energiesMeV.last()) {
        return false;
    }

    for (int i = 0; i < energiesMeV.size(); ++i) {
        if (qFuzzyCompare(energyMeV, energiesMeV[i])) {
            *coefficient = coefficients[i];
            return true;
        }
        if (energyMeV < energiesMeV[i] && i > 0) {
            const double fraction = (energyMeV - energiesMeV[i - 1])
                                    / (energiesMeV[i] - energiesMeV[i - 1]);
            *coefficient = coefficients[i - 1]
                           + fraction * (coefficients[i] - coefficients[i - 1]);
            return true;
        }
    }

    *coefficient = coefficients.last();
    return true;
}

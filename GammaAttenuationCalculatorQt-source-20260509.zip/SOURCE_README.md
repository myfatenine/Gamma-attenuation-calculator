# Gamma Attenuation Calculator Qt

Qt/CMake source release for the Gamma Attenuation Calculator.

## Requirements

- Windows x64 desktop build, or Android arm64-v8a build
- Qt 5.15.x with MSVC 2019 64-bit kit for Windows
- Qt 6.11 Android kit, Android SDK platform 36, Android NDK r27c, and JDK 17 for Android APK builds
- Qt Sql module with SQLite driver
- CMake 3.16 or newer
- Visual Studio 2019 C++ build tools

## Windows Build

From this directory:

```powershell
cmake -S . -B build -DCMAKE_PREFIX_PATH=D:/G4/QT5/5.15.2/msvc2019_64
cmake --build build --config Release
```

Adjust `CMAKE_PREFIX_PATH` to your local Qt installation path.

The executable will be generated at:

```text
build/Release/GammaAttenuationCalculatorQt.exe
```

## Android Build

Install Qt for Android and configure an Android kit in Qt Creator. Open this
`CMakeLists.txt`, select an Android kit such as `Android Qt 6.11.0 Clang arm64-v8a`,
then build and deploy to a connected phone.

Command-line builds use the Android Qt CMake toolchain from your Qt installation.
The exact paths depend on your local SDK/NDK setup; a typical configuration is:

```powershell
E:/Qt/6.11.0/android_arm64_v8a/bin/qt-cmake.bat -S . -B build-android `
  -DANDROID_SDK_ROOT=E:/Android/Sdk `
  -DANDROID_NDK_ROOT=E:/Android/Sdk/ndk/27.2.12479018 `
  -DANDROID_ABI=arm64-v8a `
  -DANDROID_PLATFORM=android-35 `
  -DCMAKE_MAKE_PROGRAM=E:/Qt/Tools/Ninja/ninja.exe `
  -DCMAKE_CXX_COMPILER_WORKS=TRUE `
  -DCMAKE_CXX_ABI_COMPILED=TRUE `
  -DCMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY `
  -DCMAKE_HAVE_LIBC_PTHREAD=TRUE `
  -DCMAKE_THREAD_LIBS_INIT=-pthread `
  -DCMAKE_USE_PTHREADS_INIT=TRUE `
  -DHAVE_STDATOMIC=TRUE `
  -DHAVE_EGL=TRUE `
  -DHAVE_GLESv2=TRUE
cmake --build build-android --target apk --config Release
```

For APK generation, run Qt's `androiddeployqt` on the generated deployment JSON
or use Qt Creator's Deploy step. The project includes `android/AndroidManifest.xml`
and embeds `data.csv` and `NISTElementsGammaAttenuation.db` through
`resources.qrc`, so the phone build does not need external data files beside the
executable.

If CMake/Ninja stalls during Qt automoc on Windows, build through a short path
without spaces. For example, create a junction such as `E:/gacsrc` pointing to
this source directory and use `E:/gacb` as the build directory.

## Runtime Data

Desktop builds still copy `data.csv` next to the executable. Android builds read
the same file from the built-in Qt resource path `:/data/data.csv`. The NIST tab
uses the bundled `NISTElementsGammaAttenuation.db` SQLite database, copied from
the embedded resource to the app data directory before opening it with QtSql.
When the bundled database changes, the app compares the embedded database with
the copied database and refreshes the app-data copy automatically.

## Updating The NIST Database

To update the NIST attenuation database, replace
`NISTElementsGammaAttenuation.db` in this source directory and rebuild the
application. Keep the SQLite schema compatible with the current reader:

- `elements` contains `atom_number`, `name`, `symbol`, and `density`
- `materials` contains `name` and `density`
- each element or material table contains `energy` in MeV and `attencoeff` in
  `cm^2/g`

The file is embedded through `resources.qrc`, so Android APKs do not need a
separate database file after installation.

## Features

- Single-element gamma-ray attenuation calculation.
- Mixture attenuation from molecular formula.
- Mixture attenuation from manually entered element mass percentages.
- NIST calculation group with single-element, molecular-formula mixture, manual percentage mixture, and standard-material search modes.
- Chinese and English UI.
- Attenuation curve to 99% attenuation.
- Half-value layer and 95% attenuation thickness markers.
- Curve CSV export.

## Source Files

- `main.cpp`
- `MainWindow.h/.cpp`
- `AttenuationCalculator.h/.cpp`
- `AttenuationPlot.h/.cpp`
- `NistDatabase.h/.cpp`
- `CMakeLists.txt`
- `data.csv`
- `NISTElementsGammaAttenuation.db`
- `resources.qrc`
- `android/AndroidManifest.xml`

## Reference

The NIST standard-material lookup is based on the local reference project
`NISTGammaSearch-master` and the bundled `NISTElementsGammaAttenuation.db`
database. The source data are from the NIST XCOM photon cross sections database:

```text
https://github.com/JW1992/NISTGammaSearch
https://www.nist.gov/pml/xcom-photon-cross-sections-database
```

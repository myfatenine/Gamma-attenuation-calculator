param(
    [string]$QtRoot = "E:/Qt/6.11.0/android_arm64_v8a",
    [string]$SdkRoot = "E:/Android/Sdk",
    [string]$NdkRoot = "E:/Android/Sdk/ndk/27.2.12479018",
    [string]$BuildDir = "build-android-arm64"
)

$ErrorActionPreference = "Stop"

& "$QtRoot/bin/qt-cmake.bat" -S . -B $BuildDir -G Ninja `
    -DANDROID_SDK_ROOT=$SdkRoot `
    -DANDROID_NDK_ROOT=$NdkRoot `
    -DANDROID_ABI=arm64-v8a `
    -DCMAKE_ANDROID_ARCH_ABI=arm64-v8a `
    -DANDROID_PLATFORM=android-35 `
    -DCMAKE_MAKE_PROGRAM=E:/Qt/Tools/Ninja/ninja.exe `
    -DCMAKE_CXX_COMPILER_WORKS=TRUE `
    -DCMAKE_CXX_ABI_COMPILED=TRUE `
    -DCMAKE_TRY_COMPILE_TARGET_TYPE=STATIC_LIBRARY `
    -DCMAKE_HAVE_LIBC_PTHREAD=TRUE `
    -DCMAKE_THREAD_LIBS_INIT=-pthread `
    -DCMAKE_USE_PTHREADS_INIT=TRUE `
    -DHAVE_STDATOMIC=TRUE `
    -DHAVE_EGL=TRUE `
    -DHAVE_GLESv2=TRUE

cmake --build $BuildDir --target apk --config Release

#include "AttenuationCalculator.h"

#include <QCoreApplication>
#include <QFile>
#include <QRegularExpression>
#include <QTextStream>

#include <cmath>
#include <stdexcept>

namespace {

const QVector<ElementInfo> kElements = {
    {1, "H", "Hydrogen", 1.008},
    {2, "He", "Helium", 4.002602},
    {3, "Li", "Lithium", 6.94},
    {4, "Be", "Beryllium", 9.0121831},
    {5, "B", "Boron", 10.81},
    {6, "C", "Carbon", 12.011},
    {7, "N", "Nitrogen", 14.007},
    {8, "O", "Oxygen", 15.999},
    {9, "F", "Fluorine", 18.998403163},
    {10, "Ne", "Neon", 20.1797},
    {11, "Na", "Sodium", 22.98976928},
    {12, "Mg", "Magnesium", 24.305},
    {13, "Al", "Aluminium", 26.9815385},
    {14, "Si", "Silicon", 28.085},
    {15, "P", "Phosphorus", 30.973761998},
    {16, "S", "Sulfur", 32.06},
    {17, "Cl", "Chlorine", 35.45},
    {18, "Ar", "Argon", 39.948},
    {19, "K", "Potassium", 39.0983},
    {20, "Ca", "Calcium", 40.078},
    {21, "Sc", "Scandium", 44.955908},
    {22, "Ti", "Titanium", 47.867},
    {23, "V", "Vanadium", 50.9415},
    {24, "Cr", "Chromium", 51.9961},
    {25, "Mn", "Manganese", 54.938044},
    {26, "Fe", "Iron", 55.845},
    {27, "Co", "Cobalt", 58.933194},
    {28, "Ni", "Nickel", 58.6934},
    {29, "Cu", "Copper", 63.546},
    {30, "Zn", "Zinc", 65.38},
    {31, "Ga", "Gallium", 69.723},
    {32, "Ge", "Germanium", 72.630},
    {33, "As", "Arsenic", 74.921595},
    {34, "Se", "Selenium", 78.971},
    {35, "Br", "Bromine", 79.904},
    {36, "Kr", "Krypton", 83.798},
    {37, "Rb", "Rubidium", 85.4678},
    {38, "Sr", "Strontium", 87.62},
    {39, "Y", "Yttrium", 88.90584},
    {40, "Zr", "Zirconium", 91.224},
    {41, "Nb", "Niobium", 92.90637},
    {42, "Mo", "Molybdenum", 95.95},
    {43, "Tc", "Technetium", 98.0},
    {44, "Ru", "Ruthenium", 101.07},
    {45, "Rh", "Rhodium", 102.90550},
    {46, "Pd", "Palladium", 106.42},
    {47, "Ag", "Silver", 107.8682},
    {48, "Cd", "Cadmium", 112.414},
    {49, "In", "Indium", 114.818},
    {50, "Sn", "Tin", 118.710},
    {51, "Sb", "Antimony", 121.760},
    {52, "Te", "Tellurium", 127.60},
    {53, "I", "Iodine", 126.90447},
    {54, "Xe", "Xenon", 131.293},
    {55, "Cs", "Caesium", 132.90545196},
    {56, "Ba", "Barium", 137.327},
    {57, "La", "Lanthanum", 138.90547},
    {58, "Ce", "Cerium", 140.116},
    {59, "Pr", "Praseodymium", 140.90766},
    {60, "Nd", "Neodymium", 144.242},
    {61, "Pm", "Promethium", 145.0},
    {62, "Sm", "Samarium", 150.36},
    {63, "Eu", "Europium", 151.964},
    {64, "Gd", "Gadolinium", 157.25},
    {65, "Tb", "Terbium", 158.92535},
    {66, "Dy", "Dysprosium", 162.500},
    {67, "Ho", "Holmium", 164.93033},
    {68, "Er", "Erbium", 167.259},
    {69, "Tm", "Thulium", 168.93422},
    {70, "Yb", "Ytterbium", 173.045},
    {71, "Lu", "Lutetium", 174.9668},
    {72, "Hf", "Hafnium", 178.49},
    {73, "Ta", "Tantalum", 180.94788},
    {74, "W", "Tungsten", 183.84},
    {75, "Re", "Rhenium", 186.207},
    {76, "Os", "Osmium", 190.23},
    {77, "Ir", "Iridium", 192.217},
    {78, "Pt", "Platinum", 195.084},
    {79, "Au", "Gold", 196.966569},
    {80, "Hg", "Mercury", 200.592},
    {81, "Tl", "Thallium", 204.38},
    {82, "Pb", "Lead", 207.2},
    {83, "Bi", "Bismuth", 208.98040},
    {84, "Po", "Polonium", 209.0},
    {85, "At", "Astatine", 210.0},
    {86, "Rn", "Radon", 222.0},
    {87, "Fr", "Francium", 223.0},
    {88, "Ra", "Radium", 226.0},
    {89, "Ac", "Actinium", 227.0},
    {90, "Th", "Thorium", 232.0377},
    {91, "Pa", "Protactinium", 231.03588},
    {92, "U", "Uranium", 238.02891},
};

QString normalizedSymbol(const QString &symbol)
{
    if (symbol.isEmpty()) {
        return symbol;
    }

    QString normalized = symbol.trimmed();
    normalized[0] = normalized[0].toUpper();
    for (int i = 1; i < normalized.size(); ++i) {
        normalized[i] = normalized[i].toLower();
    }
    return normalized;
}

bool isGroupStart(QChar ch)
{
    return ch == '(' || ch == '[' || ch == '{';
}

bool isGroupEnd(QChar ch)
{
    return ch == ')' || ch == ']' || ch == '}';
}

} // namespace

bool AttenuationCalculator::loadCsv(const QString &path, QString *errorMessage)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("无法打开数据文件：%1").arg(path);
        }
        return false;
    }

    QTextStream in(&file);
    m_coefficients.clear();
    m_coefficients.resize(93);

    const QString header = in.readLine();
    Q_UNUSED(header);

    int rowCount = 0;
    while (!in.atEnd()) {
        const QString line = in.readLine().trimmed();
        if (line.isEmpty()) {
            continue;
        }

        const QStringList fields = line.split(',');
        if (fields.size() < 4) {
            if (errorMessage) {
                *errorMessage = QStringLiteral("数据文件格式错误：第 %1 行列数不足。").arg(rowCount + 2);
            }
            return false;
        }

        bool ok = false;
        const int z = fields[0].trimmed().toInt(&ok);
        if (!ok || z < 1 || z > 92) {
            if (errorMessage) {
                *errorMessage = QStringLiteral("数据文件格式错误：第 %1 行原子序数无效。").arg(rowCount + 2);
            }
            return false;
        }

        Coefficients coefficients;
        coefficients.a1 = fields[1].trimmed().toDouble(&ok);
        if (!ok) {
            return false;
        }
        coefficients.a2 = fields[2].trimmed().toDouble(&ok);
        if (!ok) {
            return false;
        }
        coefficients.a3 = fields[3].trimmed().toDouble(&ok);
        if (!ok) {
            return false;
        }

        if (fields.size() >= 7) {
            coefficients.highA1 = fields[4].trimmed().toDouble();
            coefficients.highA2 = fields[5].trimmed().toDouble();
            coefficients.highA3 = fields[6].trimmed().toDouble();
        }

        m_coefficients[z] = coefficients;
        ++rowCount;
    }

    if (rowCount != 92) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("数据文件中应包含 92 个元素，当前读取到 %1 个。").arg(rowCount);
        }
        return false;
    }

    return true;
}

bool AttenuationCalculator::isLoaded() const
{
    return m_coefficients.size() == 93;
}

double AttenuationCalculator::massAttenuationCoefficient(int atomicNumber, double energyKeV) const
{
    if (!isLoaded()) {
        throw std::runtime_error("attenuation data is not loaded");
    }
    if (atomicNumber < 1 || atomicNumber > 92) {
        throw std::out_of_range("atomic number is outside the supported range");
    }
    if (energyKeV < 100.0 || energyKeV > 20000.0) {
        throw std::out_of_range("energy is outside the supported range");
    }

    const int legacyIndex = atomicNumber - 1;
    Coefficients c = m_coefficients[atomicNumber];

    if (legacyIndex > 72 && legacyIndex <= 91 && legacyIndex != 82 && legacyIndex != 86 && legacyIndex != 87) {
        if (energyKeV > 4000.0 && energyKeV <= 20000.0) {
            c.a1 = c.highA1;
            c.a2 = c.highA2;
            c.a3 = c.highA3;
        }
    } else if (legacyIndex == 87 && energyKeV > 1250.0) {
        c.a1 = c.highA1;
        c.a2 = c.highA2;
        c.a3 = c.highA3;
    }

    if (legacyIndex <= 16) {
        return 1.0 / (c.a1 * std::pow(energyKeV, c.a2) + c.a3);
    }
    if (legacyIndex > 16 && legacyIndex <= 23) {
        return std::pow(c.a1 * energyKeV + c.a2, c.a3);
    }
    if (legacyIndex > 23 && legacyIndex <= 29) {
        return 1.0 / (c.a1 * std::log(energyKeV) + c.a2);
    }
    if (legacyIndex > 29 && legacyIndex <= 36) {
        return c.a1 / (energyKeV + c.a2) + c.a3;
    }
    if (legacyIndex > 36 && legacyIndex <= 52) {
        return c.a1 * std::pow(energyKeV, c.a2 / energyKeV);
    }

    return c.a1 * std::exp(c.a2 / (energyKeV + c.a3));
}

AttenuationResult AttenuationCalculator::calculateSingle(int atomicNumber, double energyKeV, double density) const
{
    AttenuationResult result;
    result.massCoefficient = massAttenuationCoefficient(atomicNumber, energyKeV);
    result.linearCoefficient = result.massCoefficient * density;
    result.halfValueLayer = std::log(2.0) / result.linearCoefficient;
    result.attenuation95Thickness = std::log(20.0) / result.linearCoefficient;
    return result;
}

AttenuationResult AttenuationCalculator::calculateMixture(const QVector<MixtureComponent> &components,
                                                          double energyKeV,
                                                          double density) const
{
    if (components.isEmpty()) {
        throw std::runtime_error("mixture is empty");
    }

    AttenuationResult result;
    for (const MixtureComponent &component : components) {
        result.massCoefficient += component.massFraction
                                  * massAttenuationCoefficient(component.atomicNumber, energyKeV);
    }
    result.linearCoefficient = result.massCoefficient * density;
    result.halfValueLayer = std::log(2.0) / result.linearCoefficient;
    result.attenuation95Thickness = std::log(20.0) / result.linearCoefficient;
    return result;
}

const QVector<ElementInfo> &AttenuationCalculator::elements()
{
    return kElements;
}

const ElementInfo *AttenuationCalculator::elementByAtomicNumber(int atomicNumber)
{
    if (atomicNumber < 1 || atomicNumber > kElements.size()) {
        return nullptr;
    }
    return &kElements[atomicNumber - 1];
}

const ElementInfo *AttenuationCalculator::elementBySymbol(const QString &symbol)
{
    const QString normalized = normalizedSymbol(symbol);
    for (const ElementInfo &element : kElements) {
        if (QString::fromLatin1(element.symbol) == normalized) {
            return &element;
        }
    }
    return nullptr;
}

QString AttenuationCalculator::elementLabel(int atomicNumber)
{
    const ElementInfo *element = elementByAtomicNumber(atomicNumber);
    if (!element) {
        return QString();
    }
    return QStringLiteral("%1 (%2)").arg(QString::fromLatin1(element->symbol)).arg(element->atomicNumber);
}

QVector<MixtureComponent> FormulaParser::parseMassFractions(const QString &formula, QString *errorMessage)
{
    FormulaParser parser(formula);
    QMap<int, double> atomCounts = parser.parseFormula();
    if (!parser.m_error.isEmpty()) {
        if (errorMessage) {
            *errorMessage = parser.m_error;
        }
        return {};
    }
    if (parser.m_pos != parser.m_formula.size()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("分子式中存在无法解析的字符：%1").arg(parser.m_formula.mid(parser.m_pos, 1));
        }
        return {};
    }
    if (atomCounts.isEmpty()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("请输入有效分子式。");
        }
        return {};
    }

    double totalMass = 0.0;
    for (auto it = atomCounts.cbegin(); it != atomCounts.cend(); ++it) {
        const ElementInfo *element = AttenuationCalculator::elementByAtomicNumber(it.key());
        totalMass += it.value() * element->atomicWeight;
    }

    QVector<MixtureComponent> components;
    for (auto it = atomCounts.cbegin(); it != atomCounts.cend(); ++it) {
        const ElementInfo *element = AttenuationCalculator::elementByAtomicNumber(it.key());
        components.push_back({it.key(), it.value() * element->atomicWeight / totalMass});
    }
    return components;
}

FormulaParser::FormulaParser(QString formula)
    : m_formula(std::move(formula))
{
    m_formula.remove(QRegularExpression(QStringLiteral("\\s+")));
    m_formula.replace(QChar(0x00B7), "|");
    m_formula.replace(".", "|");
}

QMap<int, double> FormulaParser::parseFormula(QChar terminator)
{
    QMap<int, double> result;
    while (m_pos < m_formula.size()) {
        const QChar ch = m_formula[m_pos];
        if (!terminator.isNull() && ch == terminator) {
            ++m_pos;
            return result;
        }
        if (ch == '|') {
            ++m_pos;
            continue;
        }

        double leadingMultiplier = 1.0;
        if (ch.isDigit()) {
            leadingMultiplier = parseNumber(1.0);
        }

        if (m_pos >= m_formula.size()) {
            m_error = QStringLiteral("分子式不能以数字结尾。");
            return {};
        }

        QMap<int, double> parsed;
        const QChar current = m_formula[m_pos];
        if (isGroupStart(current)) {
            parsed = parseGroup(current);
        } else if (current.isUpper()) {
            const QString symbol = parseElementSymbol();
            const ElementInfo *element = AttenuationCalculator::elementBySymbol(symbol);
            if (!element) {
                m_error = QStringLiteral("不支持的元素符号：%1").arg(symbol);
                return {};
            }
            parsed[element->atomicNumber] = parseNumber(1.0);
        } else if (isGroupEnd(current)) {
            if (terminator.isNull()) {
                m_error = QStringLiteral("多余的右括号：%1").arg(current);
                return {};
            }
            m_error = QStringLiteral("括号不匹配，期望 %1。").arg(terminator);
            return {};
        } else {
            m_error = QStringLiteral("无法解析的字符：%1").arg(current);
            return {};
        }

        mergeCounts(&result, parsed, leadingMultiplier);
    }

    if (!terminator.isNull()) {
        m_error = QStringLiteral("缺少右括号：%1").arg(terminator);
        return {};
    }

    return result;
}

QMap<int, double> FormulaParser::parseGroup(QChar openChar)
{
    ++m_pos;
    QMap<int, double> group = parseFormula(matchingTerminator(openChar));
    if (!m_error.isEmpty()) {
        return {};
    }

    const double multiplier = parseNumber(1.0);
    QMap<int, double> result;
    mergeCounts(&result, group, multiplier);
    return result;
}

double FormulaParser::parseNumber(double defaultValue)
{
    const int start = m_pos;
    while (m_pos < m_formula.size()) {
        const QChar ch = m_formula[m_pos];
        if (ch.isDigit()) {
            ++m_pos;
        } else {
            break;
        }
    }

    if (start == m_pos) {
        return defaultValue;
    }
    return m_formula.mid(start, m_pos - start).toDouble();
}

QString FormulaParser::parseElementSymbol()
{
    const int start = m_pos++;
    while (m_pos < m_formula.size() && m_formula[m_pos].isLower()) {
        ++m_pos;
    }
    return m_formula.mid(start, m_pos - start);
}

void FormulaParser::mergeCounts(QMap<int, double> *target, const QMap<int, double> &source, double multiplier)
{
    for (auto it = source.cbegin(); it != source.cend(); ++it) {
        (*target)[it.key()] += it.value() * multiplier;
    }
}

QChar FormulaParser::matchingTerminator(QChar openChar) const
{
    if (openChar == '(') {
        return ')';
    }
    if (openChar == '[') {
        return ']';
    }
    return '}';
}

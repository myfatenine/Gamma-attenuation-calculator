#pragma once

#include <QWidget>

class AttenuationPlot : public QWidget {
    Q_OBJECT

public:
    explicit AttenuationPlot(QWidget *parent = nullptr);

    void setLanguageText(const QString &title,
                         const QString &xAxisLabel,
                         const QString &yAxisLabel,
                         const QString &emptyText,
                         const QString &endLabel,
                         const QString &halfValueLabel,
                         const QString &attenuation95Label);
    void setLinearCoefficient(double linearCoefficient);
    void clear();
    bool hasCurve() const;
    bool exportCsv(const QString &filePath, QString *errorMessage = nullptr) const;

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    double m_linearCoefficient = 0.0;
    QString m_title;
    QString m_xAxisLabel;
    QString m_yAxisLabel;
    QString m_emptyText;
    QString m_endLabel;
    QString m_halfValueLabel;
    QString m_attenuation95Label;
};

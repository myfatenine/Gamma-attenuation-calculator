#include "AttenuationPlot.h"

#include <QFile>
#include <QPainter>
#include <QPainterPath>
#include <QPen>
#include <QTextStream>

#include <algorithm>
#include <cmath>

AttenuationPlot::AttenuationPlot(QWidget *parent)
    : QWidget(parent)
{
    setMinimumHeight(220);
}

void AttenuationPlot::setLanguageText(const QString &title,
                                      const QString &xAxisLabel,
                                      const QString &yAxisLabel,
                                      const QString &emptyText,
                                      const QString &endLabel,
                                      const QString &halfValueLabel,
                                      const QString &attenuation95Label)
{
    m_title = title;
    m_xAxisLabel = xAxisLabel;
    m_yAxisLabel = yAxisLabel;
    m_emptyText = emptyText;
    m_endLabel = endLabel;
    m_halfValueLabel = halfValueLabel;
    m_attenuation95Label = attenuation95Label;
    update();
}

void AttenuationPlot::setLinearCoefficient(double linearCoefficient)
{
    m_linearCoefficient = linearCoefficient;
    update();
}

void AttenuationPlot::clear()
{
    m_linearCoefficient = 0.0;
    update();
}

bool AttenuationPlot::hasCurve() const
{
    return m_linearCoefficient > 0.0 && std::isfinite(m_linearCoefficient);
}

bool AttenuationPlot::exportCsv(const QString &filePath, QString *errorMessage) const
{
    if (!hasCurve()) {
        if (errorMessage) {
            *errorMessage = QStringLiteral("No curve data to export.");
        }
        return false;
    }

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        if (errorMessage) {
            *errorMessage = file.errorString();
        }
        return false;
    }

    const double xMax = std::log(100.0) / m_linearCoefficient;
    const double halfThickness = std::log(2.0) / m_linearCoefficient;
    const double attenuation95Thickness = std::log(20.0) / m_linearCoefficient;

    QTextStream out(&file);
    out.setRealNumberNotation(QTextStream::FixedNotation);
    out.setRealNumberPrecision(10);
    out << "type,thickness_cm,attenuation_percent,remaining_percent\n";
    for (int i = 0; i <= 200; ++i) {
        const double x = xMax * i / 200.0;
        const double attenuationPercent = (1.0 - std::exp(-m_linearCoefficient * x)) * 100.0;
        out << "curve," << x << "," << attenuationPercent << "," << 100.0 - attenuationPercent << "\n";
    }
    out << "half_value_layer," << halfThickness << ",50,50\n";
    out << "attenuation_95_percent," << attenuation95Thickness << ",95,5\n";
    out << "attenuation_99_percent," << xMax << ",99,1\n";
    return true;
}

void AttenuationPlot::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);
    painter.fillRect(rect(), palette().base());

    const QRectF area = rect().adjusted(16, 12, -16, -14);
    painter.setPen(QPen(QColor(210, 210, 210), 1));
    painter.setBrush(Qt::NoBrush);
    painter.drawRoundedRect(area, 6, 6);

    painter.setPen(palette().text().color());
    QFont titleFont = painter.font();
    titleFont.setBold(true);
    painter.setFont(titleFont);
    painter.drawText(area.adjusted(10, 6, -10, 0), Qt::AlignTop | Qt::AlignHCenter, m_title);

    QFont axisFont = painter.font();
    axisFont.setBold(false);
    axisFont.setPointSize(std::max(8, axisFont.pointSize() - 1));
    painter.setFont(axisFont);

    if (!hasCurve()) {
        painter.setPen(QColor(120, 120, 120));
        painter.drawText(area, Qt::AlignCenter, m_emptyText);
        return;
    }

    const double xMax = std::log(100.0) / m_linearCoefficient;
    if (xMax <= 0.0 || !std::isfinite(xMax)) {
        painter.setPen(QColor(120, 120, 120));
        painter.drawText(area, Qt::AlignCenter, m_emptyText);
        return;
    }

    const QRectF plot = area.adjusted(58, 38, -20, -42);
    painter.setPen(QPen(QColor(225, 225, 225), 1));
    for (int i = 0; i <= 4; ++i) {
        const double y = plot.top() + plot.height() * i / 4.0;
        painter.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y));
    }

    painter.setPen(QPen(QColor(90, 90, 90), 1.2));
    painter.drawLine(plot.bottomLeft(), plot.bottomRight());
    painter.drawLine(plot.bottomLeft(), plot.topLeft());

    painter.setPen(QColor(90, 90, 90));
    painter.drawText(QRectF(plot.left() - 54, plot.bottom() - 10, 46, 18),
                     Qt::AlignRight | Qt::AlignVCenter,
                     QStringLiteral("0"));
    painter.drawText(QRectF(plot.left() - 54, plot.top() - 10, 46, 18),
                     Qt::AlignRight | Qt::AlignVCenter,
                     QStringLiteral("99"));
    painter.drawText(QRectF(plot.left() - 20, plot.bottom() + 6, 40, 18),
                     Qt::AlignCenter,
                     QStringLiteral("0"));
    painter.drawText(QRectF(plot.right() - 72, plot.bottom() + 6, 144, 18),
                     Qt::AlignCenter,
                     QStringLiteral("%1 cm").arg(QString::number(xMax, 'g', 4)));

    painter.drawText(QRectF(plot.left(), area.bottom() - 24, plot.width(), 20),
                     Qt::AlignCenter,
                     m_xAxisLabel);

    painter.save();
    painter.translate(area.left() + 15, plot.center().y());
    painter.rotate(-90);
    painter.drawText(QRectF(-plot.height() / 2.0, -8, plot.height(), 16),
                     Qt::AlignCenter,
                     m_yAxisLabel);
    painter.restore();

    QPainterPath curve;
    for (int i = 0; i <= 180; ++i) {
        const double x = xMax * i / 180.0;
        const double attenuationPercent = (1.0 - std::exp(-m_linearCoefficient * x)) * 100.0;
        const double px = plot.left() + plot.width() * x / xMax;
        const double py = plot.bottom() - plot.height() * attenuationPercent / 99.0;
        if (i == 0) {
            curve.moveTo(px, py);
        } else {
            curve.lineTo(px, py);
        }
    }

    painter.setPen(QPen(QColor(30, 105, 190), 2.4));
    painter.drawPath(curve);

    const double halfThickness = std::log(2.0) / m_linearCoefficient;
    const double attenuation95Thickness = std::log(20.0) / m_linearCoefficient;
    const double markerValues[2] = {halfThickness, attenuation95Thickness};
    const double markerPercents[2] = {50.0, 95.0};
    const QString markerLabels[2] = {
        QStringLiteral("%1: %2 cm").arg(m_halfValueLabel).arg(QString::number(halfThickness, 'g', 4)),
        QStringLiteral("%1: %2 cm").arg(m_attenuation95Label).arg(QString::number(attenuation95Thickness, 'g', 4))
    };
    const QColor markerColors[2] = {QColor(220, 125, 35), QColor(70, 145, 95)};

    for (int i = 0; i < 2; ++i) {
        const double px = plot.left() + plot.width() * markerValues[i] / xMax;
        const double py = plot.bottom() - plot.height() * markerPercents[i] / 99.0;

        QPen markerPen(markerColors[i], 1.4, Qt::DashLine);
        painter.setPen(markerPen);
        painter.drawLine(QPointF(px, plot.bottom()), QPointF(px, plot.top()));
        painter.drawLine(QPointF(plot.left(), py), QPointF(px, py));

        painter.setPen(QPen(markerColors[i], 1.0));
        painter.setBrush(markerColors[i]);
        painter.drawEllipse(QPointF(px, py), 3.5, 3.5);

        const QRectF labelRect(i == 0
                                   ? QRectF(px + 6, py - 22, 150, 20)
                                   : QRectF(px - 154, py - 24, 150, 20));
        painter.setBrush(QColor(255, 255, 255, 220));
        painter.setPen(QPen(markerColors[i], 1.0));
        painter.drawRoundedRect(labelRect, 3, 3);
        painter.setPen(markerColors[i]);
        painter.drawText(labelRect.adjusted(4, 0, -4, 0), Qt::AlignVCenter, markerLabels[i]);
    }

    painter.setPen(QColor(30, 105, 190));
    painter.drawText(QRectF(plot.right() - 130, plot.top() + 6, 124, 18),
                     Qt::AlignRight | Qt::AlignVCenter,
                     m_endLabel);
}
